import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;
import javax.swing.text.BadLocationException;
import java.util.regex.Pattern;
import javax.swing.*;
import javax.swing.border.TitledBorder;

/**
 * Crea il pannello generale delle opzioni di evilproxy
 * @author s4tan
 *
 */

public class GeneralPanel implements ActionListener, DocumentListener {
	private JPanel panel;
	private JPanel panelGeneral;
	private JPanel mainPanel;
	private JTextField portEP;
	private JTextField timeoutEP;
	private JTextField ignoredFiles;
	private JTextField logRequestField;
	private JButton startServer;
	private JButton stopServer;
	private JButton browseFile;
	private Proxy proxy = new Proxy();
	private JLabel generalError;
	private JCheckBox logRequest;
	private JCheckBox urlCompliant;
	private JCheckBox intercept;
	private JCheckBox ignore;
	private JCheckBox update;
	private JCheckBox logResponse;
	private JCheckBox interceptS;
	private JCheckBox ignoreS;
	private JCheckBox updateS;
	private JCheckBox ungunzip;
	public JLabel errorOptionsSetting;
		
	GeneralPanel() {
			
		panel = new JPanel(new GridBagLayout());		
		panel.setBackground(new Color(255,255,255));
		mainPanel = new JPanel(new GridBagLayout());
		mainPanel.setBackground(new Color(255,255,255));
		GridBagConstraints layout;
		generalError = new JLabel(" ");
		generalError.setForeground(new Color(255,0,0));
		generalError.setPreferredSize(new Dimension(400,20));
		
		panel.setPreferredSize(new Dimension(540,120));
		TitledBorder bordo =BorderFactory.createTitledBorder( BorderFactory.createLineBorder(new Color(223,217,233))," EvilProxy Options ");		
		panel.setBorder(bordo);
		// Creo i componenti da inserire nel pannello principale
		JLabel labelPortEP = new JLabel("EvilProxy running on port  ");
		labelPortEP.setToolTipText("Activate EvilProxy on the specified port");
		portEP = new JTextField(String.valueOf(OptionControl.portEvilProxy),7);		
		
		JLabel labelTimeoutEP = new JLabel("Network timeout [millisec]");
		labelTimeoutEP.setToolTipText("Specified the waiting time before to declare that there is no response from the server");
		timeoutEP = new JTextField(String.valueOf(OptionControl.TIMEOUT),7);		
		
		// Creo il bottone di start del server
		Icon start = new ImageIcon("./img/start.gif");
		startServer = new JButton(new InsetsIcon(start));
		startServer.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		startServer.setRolloverEnabled(true);
		startServer.addActionListener(this);
		startServer.setActionCommand("startServer");		;
		startServer.setToolTipText("Start EvilProxy Server");
		startServer.setRolloverIcon(new ShadowedIcon(start));
		startServer.setBorderPainted(false);		
		startServer.setPreferredSize(new Dimension(32,30));		
		startServer.setBackground(new Color(255,255,255));
		startServer.setDisabledIcon(new ImageIcon("./img/startDisabled.gif"));
			
		// Creo il bottone di stop del server
		Icon stop = new ImageIcon("./img/drop.gif");
		stopServer = new JButton(new InsetsIcon(stop));
		stopServer.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		stopServer.addActionListener(this);
		stopServer.setActionCommand("stopServer");
		stopServer.setRolloverEnabled(true);		
		stopServer.setToolTipText("Stop EvilProxy server");
		stopServer.setRolloverIcon(new ShadowedIcon(stop));
		stopServer.setBorderPainted(false);		
		stopServer.setPreferredSize(new Dimension(32,30));	
		stopServer.setBackground(new Color(255,255,255));
		stopServer.setDisabledIcon(new ImageIcon("./img/dropDisabled.gif"));
		
		// Verifico in che stato sono
		if (OptionControl.isServerOn) {
			serverIsWorking();
		}
		else {
			serverIsStopped();
		}	
		
		// Aggiungo i vari componenti
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;	
		layout.gridwidth = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;		
		panel.add(labelPortEP,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 2;
		layout.gridy = 0;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;		
		panel.add(portEP,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 1;	
		layout.gridwidth = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;		
		panel.add(labelTimeoutEP,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 2;
		layout.gridy = 1;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;		
		panel.add(timeoutEP,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 2;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;		
		panel.add(startServer,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 2;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;		
		panel.add(stopServer,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 3;	
		layout.gridwidth = 3;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;		
		panel.add(generalError,layout);
		
		// Creo il pannello per le opzioni generali
		panelGeneral = new JPanel(new GridBagLayout());		
		panelGeneral.setBackground(new Color(255,255,255));		
		JPanel destra = new JPanel(new GridBagLayout());
		destra.setPreferredSize(new Dimension(270,150));
		destra.setBackground(new Color(255,255,255));
		JPanel sinistra = new JPanel(new GridBagLayout());
		sinistra.setPreferredSize(new Dimension(270,150));
		sinistra.setBackground(new Color(255,255,255));
		bordo =BorderFactory.createTitledBorder( BorderFactory.createLineBorder(new Color(223,217,233))," General Options ");		
		panelGeneral.setBorder(bordo);
		errorOptionsSetting = new JLabel(" ");
		errorOptionsSetting.setForeground(new Color(255,0,0));		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;
		layout.weighty = 1.0;
		layout.weightx = 1.0;
		layout.fill = GridBagConstraints.BOTH;	
		panelGeneral.add(sinistra,layout);
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 0;
		layout.weighty = 1.0;
		layout.weightx = 1.0;
		layout.fill = GridBagConstraints.BOTH;	
		panelGeneral.add(destra,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 1;
		layout.gridwidth = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		panelGeneral.add(errorOptionsSetting,layout);
		
		// Creo il pannello di sinistra
		// Creo prima tutti i componenti e le loro preferenze
		JLabel labelClient = new JLabel("<html><body><i>Client requests</i></body></html>");
		labelClient.setMinimumSize(new Dimension(200,20));
		intercept = new JCheckBox("Intercept");
		intercept.setToolTipText("Display client requests in the  intercept tab");
		intercept.setBackground(new Color(255,255,255));
		intercept.setSelected(OptionControl.interceptClientRequest);
		intercept.addActionListener(this);
		intercept.setActionCommand("interceptC");		
		ignore = new JCheckBox("Ignore ");
		ignore.setBackground(new Color(255,255,255));
		ignore.setToolTipText("Do not log and do not intercept for the specified filetypes");
		ignore.addActionListener(this);
		ignore.setActionCommand("ignoreC");
		ignore.setSelected(OptionControl.ignoreClientFiletypes);
		ignoredFiles = new JTextField("",40);
		ignoredFiles.setMinimumSize(new Dimension(150,20));
		ignoredFiles.setText(OptionControl.ignoredClientFiletypes);
		ignoredFiles.getDocument().addDocumentListener(this);
		ignoredFiles.getDocument().putProperty("key","ignoredFiles");
		ignoredFiles.setEditable(!OptionControl.ignoreClientFiletypes);
		update = new JCheckBox("Update Content-Length ");
		update.setMinimumSize(new Dimension(200,20));
		update.setBackground(new Color(255,255,255));
		update.setSelected(OptionControl.updateClientContentLength);
		update.addActionListener(this);
		update.setActionCommand("updateC");
		update.setToolTipText("Automatically update the Content-Length field when the request is edited");		
		logRequest = new JCheckBox("Log requests to");		
		logRequest.setBackground(new Color(255,255,255));
		logRequest.setSelected(OptionControl.logClientRequestToFile);
		logRequest.addActionListener(this);
		logRequest.setActionCommand("logRequest");
		logRequest.setToolTipText("Log the client requests to the specified file");		
		logRequestField = new JTextField("",40);
		logRequestField.setMinimumSize(new Dimension(118,20));	
		logRequestField.setText(OptionControl.filenameLogRequests);	
		logRequestField.setEditable(!OptionControl.logClientRequestToFile);
		logRequestField.getDocument().addDocumentListener(this);
		logRequestField.getDocument().putProperty("key","logRequest");		
		browseFile = new JButton(new ImageIcon("./img/browse.gif"));
		browseFile.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		browseFile.setMinimumSize(new Dimension(30,20));
		browseFile.setBackground(new Color(255,255,255));
		browseFile.setToolTipText("Browse files");	
		browseFile.setActionCommand("browseFiles");
		browseFile.addActionListener(this);			
		urlCompliant = new JCheckBox("Encode parameters");		
		urlCompliant.setBackground(new Color(255,255,255));
		urlCompliant.setSelected(OptionControl.doParametersUrlCompliant);
		urlCompliant.addActionListener(this);
		urlCompliant.setActionCommand("urlCompliant");
		urlCompliant.setToolTipText("Convert a String to the application/x-www-form-urlencoded MIME format");		
		
		// Aggiungo i componenti al pannello di sinistra
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;
		layout.gridwidth = 3;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		sinistra.add(labelClient,layout);
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 1;
		layout.gridwidth = 3;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		sinistra.add(intercept,layout);
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		sinistra.add(ignore,layout);
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 2;
		layout.gridwidth = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		sinistra.add(ignoredFiles,layout);
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 3;
		layout.gridwidth = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		sinistra.add(update,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 4;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		sinistra.add(logRequest,layout);
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 4;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		sinistra.add(logRequestField,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 2;
		layout.gridy = 4;		
		layout.anchor = GridBagConstraints.FIRST_LINE_END;			
		sinistra.add(browseFile,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 5;		
		layout.gridwidth = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		sinistra.add(urlCompliant,layout);		
		
		
		// Creo il pannello di destra
		// Creo prima tutti i componenti e le loro preferenze
		JLabel serverClient = new JLabel("<html><body><i>Server responses</i></body></html>");
		serverClient.setMinimumSize(new Dimension(200,20));
		interceptS = new JCheckBox("Intercept");
		interceptS.setToolTipText("Display server responses in the  intercept tab");
		interceptS.setBackground(new Color(255,255,255));
		interceptS.setSelected(OptionControl.interceptServerResponse);
		interceptS.addActionListener(this);
		interceptS.setActionCommand("interceptS");	
		ignoreS = new JCheckBox("Ignore non-text");
		ignoreS.setBackground(new Color(255,255,255));
		ignoreS.setToolTipText("Ignore non-text content types");
		ignoreS.setSelected(OptionControl.ignoreServerNonTextResponse);
		ignoreS.addActionListener(this);
		ignoreS.setActionCommand("ignoreS");	
		updateS = new JCheckBox("Update Content-Length");
		updateS.setMinimumSize(new Dimension(200,20));
		updateS.setBackground(new Color(255,255,255));
		updateS.addActionListener(this);
		updateS.setActionCommand("updateS");
		updateS.setSelected(OptionControl.updateServerContentLength);
		updateS.setToolTipText("Automatically update the Content-Length field when the response is edited");		
		logResponse = new JCheckBox("Include responses in log file");
		logResponse.setToolTipText("Include the server responses in the log file");
		logResponse.setBackground(new Color(255,255,255));
		logResponse.setSelected(OptionControl.logServerResponseToFile);
		logResponse.addActionListener(this);
		logResponse.setActionCommand("logResponse");
		ungunzip = new JCheckBox("Unpack gunzip");
		ungunzip.setToolTipText("Extract compressed message body");
		ungunzip.setBackground(new Color(255,255,255));
		ungunzip.setSelected(OptionControl.ungunzipResponse);
		ungunzip.addActionListener(this);
		ungunzip.setActionCommand("ungunzip");	
		
		// Aggiungo i componenti al pannello di sinistra
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		destra.add(serverClient,layout);
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 1;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		destra.add(interceptS,layout);
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		destra.add(ignoreS,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 3;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		destra.add(updateS,layout);
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 4;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		destra.add(logResponse,layout);
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 5;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		destra.add(ungunzip,layout);
				
	}
	
	public void insertUpdate(DocumentEvent e) {
		handle(e);
	}
	
	public void removeUpdate(DocumentEvent e) {
		handle(e);
	}
	
	public void changedUpdate(DocumentEvent e) {
		handle(e);
	}
	
	private void handle(DocumentEvent e) {
		Document d = e.getDocument();
		String value = (String)d.getProperty("key");
		if (value.equals("ignoredFiles")) {
			try {
				OptionControl.ignoredClientFiletypes = d.getText(0,d.getLength());
			}
			catch (BadLocationException ignored) {}			
		}
		else if (value.equals("logRequest")) {
			try {
				OptionControl.filenameLogRequests = d.getText(0,d.getLength());
			}
			catch (BadLocationException ignored) {}			
		}
	}
	
	public void actionPerformed(ActionEvent e) {		
		if (e.getSource() instanceof JButton) {
			if (e.getActionCommand() == "startServer") { // Avvio il server
				// premuto il tasto General
				String p = portEP.getText();
				String t = timeoutEP.getText();
				int pn = 0;
				int tn = 0;
				String regex = "^\\d*?$"; // Indica che ho solo delle cifre	
				if (p != null && !p.equals("") && Pattern.matches(regex,p) && (pn = (int)Long.parseLong(p)) > 0 && pn <= 65535 &&
						t != null && !t.equals("") && Pattern.matches(regex,t) && (tn = (int)Long.parseLong(t)) > 0) {					
					OptionControl.portEvilProxy = pn;					
					OptionControl.TIMEOUT = tn;
					proxy.startServer();
					generalError.setText(" ");
					// Controllo se l'avvio del server è andato a buon fine
					if (OptionControl.isServerOn) { // Avvio riuscito											
						serverIsWorking();
					}
					else { // Avvio non riuscito
						serverIsStopped();							
					}
				}
				else {
					generalError.setText("Error: One or more fields don't have a correct value");
				}								
			}
			else if (e.getActionCommand() == "stopServer") { // Fermo il server
				// premuto il tasto Proxy Options								
				proxy.stopServer();
				generalError.setText(" ");
				serverIsStopped();
			}	
			else if (e.getActionCommand() == "browseFiles") { // Browse tra i file
				// premuto il tasto Proxy Options				
				JFileChooser choose = new JFileChooser();
				choose.setDialogTitle("Choose log file");				
				int result = choose.showDialog(null,"Select");								
				if (result == JFileChooser.APPROVE_OPTION) {
					OptionControl.filenameLogRequests = choose.getSelectedFile().getPath();
					logRequestField.setText(OptionControl.filenameLogRequests);	
				}
			}	
		}		
		else if (e.getSource() instanceof JCheckBox) { // Gestione delle opzioni generali
			errorOptionsSetting.setText(" ");
			if (e.getActionCommand() == "interceptC") {
				OptionControl.interceptClientRequest = intercept.isSelected();
			}
			else if (e.getActionCommand() == "ignoreC") {
				OptionControl.ignoreClientFiletypes = ignore.isSelected();
				ignoredFiles.setEditable(!OptionControl.ignoreClientFiletypes);
			}			
			else if (e.getActionCommand() == "updateC") {
				OptionControl.updateClientContentLength = update.isSelected();
			}
			else if (e.getActionCommand() == "urlCompliant") {
				OptionControl.doParametersUrlCompliant = urlCompliant.isSelected();
			}
			else if (e.getActionCommand() == "interceptS") {
				OptionControl.interceptServerResponse = interceptS.isSelected();
			}
			else if (e.getActionCommand() == "ignoreS") {
				OptionControl.ignoreServerNonTextResponse = ignoreS.isSelected();
			}
			else if (e.getActionCommand() == "updateS") {
				OptionControl.updateServerContentLength = updateS.isSelected();
			}
			else if (e.getActionCommand() == "logResponse") {
				OptionControl.logServerResponseToFile = logResponse.isSelected();				
			}
			else if (e.getActionCommand() == "logRequest") {				
				if (logRequest.isSelected()) { // Creo il file
					if (SchedulerRequest.createLog() != -1) {					
						OptionControl.logClientRequestToFile = logRequest.isSelected();
						logRequestField.setEditable(!OptionControl.logClientRequestToFile);
						browseFile.setEnabled(!OptionControl.logClientRequestToFile);
					}
					else {
						errorOptionsSetting.setText("Error: No such file or directory");
						logRequest.setSelected(false);
					}
				}
				else { // Chiudo il file
					SchedulerRequest.closeLog();
					OptionControl.logClientRequestToFile = logRequest.isSelected();
					logRequestField.setEditable(!OptionControl.logClientRequestToFile);
					browseFile.setEnabled(!OptionControl.logClientRequestToFile);
				}
			}
			else if (e.getActionCommand() == "ungunzip") {
				OptionControl.ungunzipResponse = ungunzip.isSelected();
			}
		}
	}
	
	
	/**
	 * Funzione che specifica le azioni da prendere se il server è attivo
	 *
	 */
	private void serverIsWorking() {
		startServer.setEnabled(false);
		stopServer.setEnabled(true);
		portEP.setEditable(false);
		timeoutEP.setEditable(false);
	}
	
	/**
	 * Funzione che specifica le azioni da prendere se il server è fermo
	 *
	 */
	private void serverIsStopped() {
		startServer.setEnabled(true);
		stopServer.setEnabled(false);
		portEP.setEditable(true);
		timeoutEP.setEditable(true);
	}
	
	
	public JPanel getPanel() {
		GridBagConstraints layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;	
		layout.weightx = 1.0;		
		layout.fill = GridBagConstraints.HORIZONTAL;	
		mainPanel.add(new JLabel(new ImageIcon("./img/generalBar.gif")),layout);
		
		JPanel scrolledPanel = new JPanel(new GridBagLayout());
				
		layout.gridx = 0;
		layout.gridy = 1;	
		layout.weighty = 1.0;
		layout.weightx = 1.0;		
		layout.fill = GridBagConstraints.BOTH;	
		scrolledPanel.add(panel,layout);
				
		layout.gridx = 0;
		layout.gridy = 2;	
		layout.weighty = 1.0;
		layout.weightx = 1.0;		
		layout.fill = GridBagConstraints.BOTH;		
		scrolledPanel.add(panelGeneral,layout);		
		
		
		JScrollPane scrollArea = new JScrollPane(scrolledPanel);
		scrollArea.setAutoscrolls(true);
		scrollArea.setPreferredSize(new Dimension(570,310));
		scrollArea.setBorder(null);
		mainPanel.add(scrollArea,layout);
		return mainPanel;
	}
}
