import java.util.regex.Pattern;

/**
 * Classe che avvia il programma. E' stata messa in una classe a parte, in modo da permettere ad applicazioni esterne 
 * di crearne un nuovo oggetto e di invocarla, senza ricorrere al genereazione di processi tramite shell.
 * @author s4tan
 *
 */
public class ep {
	private int lf = 0;
	
	public void startEvilProxy() {	
		OptionControl o = new OptionControl(); // Istanzio l'oggetto per l'inizializzazione degli oggetti
		Proxy proxy = new Proxy();
		proxy.start(); // avvio il server
				
		BaseFrame gui = new BaseFrame();
		gui.setInteractive(OptionControl.isInteractive());
		gui.showGUI(lf);	
			
	}
	
	/**
	 * Inizializza le strutture di EvilProxy
	 *
	 */
	ep(String[] args) {
		if (args != null && args.length > 0) {
			for(int i=0;i<args.length;i++) {
				String arg = args[i];
				
				if (arg.startsWith("-i=")) {
					String p = arg.substring(3);
					if (p.toLowerCase().equals("0")) {
						OptionControl.isInteractive = false;
					}
				}
				else if (arg.startsWith("-p=")) {
					String regex = "^\\d*?$";
					String p = arg.substring(3);
					if (Pattern.matches(regex,p)) {						
						OptionControl.portEvilProxy = Integer.valueOf(p).intValue();
					}
					else {						
						this.printUsage();
					}
				}			
				else if (arg.startsWith("-l=")) {
					String p = arg.substring(3);
					if (p.toLowerCase().equals("windows")) {
						lf = 1;
					}					
				}
				else {
					this.printUsage();
				}
			}
		}
	}
	
	private void printUsage() {
		StringBuilder sb = new StringBuilder();
		sb.append("\nUsage: java -Xmx256m -classpath .:lib/itp-gpl.jar:jl1.0.jar evilproxy [-option=<value>]\n\n");
		sb.append("Where option are:\n\n");
		sb.append(" -p\tEvilProxy port\n");
		sb.append(" -l\tSet the Look&Feel\n");
		sb.append(" -i\tIf value=1 Set interactive mode, else EvilProxy run in not interactive mode\n");
		sb.append(" -h\tShow this help\n");
		System.out.println(sb.toString());
		System.exit(1);
	}

}
