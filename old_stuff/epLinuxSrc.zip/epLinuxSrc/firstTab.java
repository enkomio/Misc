import java.awt.*;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.TableModel;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelListener;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.DefaultTableCellRenderer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.net.URLEncoder;
import java.io.UnsupportedEncodingException;

/**
 * Definizione del primo tab
 * @author s4tan
 *
 */
public class firstTab implements ActionListener, DocumentListener, TableModelListener {
	private JPanel panel;
	private JPanel panelInteractiveArea;
	public static JPanel panelTextArea;	
	public static JPanel panelTableParametersArea;
	private JPanel viewPanel;
	private GridBagConstraints c;		
	private GridBagConstraints TextArea;
	private GridBagConstraints TableArea;
	private GridBagConstraints parameterArea;
	private static JButton buttonStart;
	private static JButton buttonStop;
	private static JRadioButton textView;
	private static JRadioButton hexView;
	private static JRadioButton parameterView;
	private JLabel info;
	public static JLabel infoProxy;
	
	private static JTable table;
	private static JTable tableParameters;
	private myTableModel myModel;
	private static myTableParametersModel myModelParameters;
	private JScrollPane scrollTableArea;
	private JScrollPane scrollTableParametersArea;
	private static String currentRequest = ""; // Contiene il testo della richiesta che si stà esaminando
	private final int NUMCOLTABLE = 16;
	private SearchField search;
	
	private static JPanel panParamsBottom;
	private static JLabel labelAction;
	private static JButton paramsAdd;
	private static JButton paramsDel;
	
	private int currentCaretPosition = 0;
	
	private static JTextArea text;
	private JScrollPane scrollTextArea;
	
	public static int decision = -1;		
	
	private String[] columnNames = {"#","0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","ASCII Text"};
	private String[] columnParametersNames = {"#","Info","Name","Value"};
	private String[] parametersType = {"Url Parameter","Body Parameter","Cookie"};
	
	private String item = "";	// Nome del parametro selezionato
	private String value = "";	// Valore del parametro selezionato
	private String type = "";	// Tipo del valore del parametro selezionato
	private HashMap<String,String> parPosition = new HashMap<String,String>(); // Indica la posizione in cui è presente la stringa all'interno della richiesta, Sono due numeri separati da una virgola
	
	/**
	 * Imposta la richiesta e la visualizza nell'apposita vista che è al momento selezionata
	 * @param req
	 */
	public void setRequest(String req) {
		currentRequest = req;
		text.setText(currentRequest);		
		impostaRichiestaInTabella();		
	}
	
	public void setInfoRequest(String req) {
		info.setIcon(null); // Elimino l'eventuale immagine disegnata		
		info.setText(req);		
	}
	
	public void setInfoRequest(String req, boolean ssl) { // Imposto anche il lucchetto	
		info.setText(req);		
		if (ssl) {
			Icon sslI = new ImageIcon("./img/ssl.gif");
			info.setIcon(sslI);
		}		
	}
	
	private void clearRichiestaInTabella() {
		myModel.setRowCount(0);	
	}
	
	private void impostaRichiestaInTabella() {
		currentRequest = updateContentLength(currentRequest);
		String req = new String(currentRequest);
		myModel.setRowCount(0);		
		if (req == null || req.length() == 0 ) {			
			return;
		}
		
		boolean finito = false;
		int len = 0;
		int indice = 0;
		// Mi calcolo la dimensione dei dati da impostare
		int col = NUMCOLTABLE;
		int row = (int)(req.length() / col);
		int resto = req.length() % col;
		if (resto != 0) { // arrotondo all'estremo superiore
			row++;
		}		
		String[][] data = new String[row][col+2];
		while(!finito) {			
			
			int end = len+col;
			if (len+col >= req.length()) {
				end = req.length();
				finito = true; // Ho esaminato tutti i caratteri della richiesta				
			}			
			
			String riga = req.substring(len,end);
			len = end; // imposto il nuovo punto di partenza			
				
			data[indice][0] = String.valueOf(indice);
			for(int i=0;i<riga.length();i++) {	
				String tmp = Integer.toHexString((int)riga.charAt(i));
				if (tmp.length() < 2) {
					tmp = "0"+tmp;
				}
				data[indice][i+1] = tmp; 
			}
			data[indice][17] = riga;
			indice++;	
			if (finito == true) {				
				myModel.setLastCellEditable(riga.length()); 
			}
		}		
				
		boolean v = table.isVisible();
		table.setVisible(false);
		myModel.setDataVector(data,columnNames);
		setColumnWidth();		
		table.setVisible(v);
	}
	
	
	firstTab() {
		// Creo le tre aree
		creaTextArea();
		creaTableArea();
		creaParametersArea();
		
		panel = new JPanel(new GridBagLayout());
		panel.setBackground(new Color(255,255,255));
		panelInteractiveArea = new JPanel(new GridBagLayout());
		panelInteractiveArea.setBackground(new Color(255,255,255));		
				
		// Visualizzo la TextArea
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 1;
		c.weighty = 1.0;
		c.weightx = 1.0;
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 2;
		panel.add(panelInteractiveArea,c);
					
		// Creo il pannello
		JPanel buttonPanel = new JPanel(new GridBagLayout());
		buttonPanel.setBackground(new Color(255,255,255));
		
		// Creo il bottone di forward
		Icon forward = new ImageIcon("./img/forward.gif");
		buttonStart = new JButton(new InsetsIcon(forward));
		buttonStart.setRolloverEnabled(true);
		buttonStart.setToolTipText("Forward the message");
		buttonStart.setRolloverIcon(new ShadowedIcon(forward));
		buttonStart.setBorderPainted(false);
		buttonStart.setEnabled(false);		
		buttonStart.setPreferredSize(new Dimension(32,30));		
		buttonStart.setDisabledIcon(new ImageIcon("./img/forwardDisabled.gif"));
		buttonStart.addActionListener(this);
		buttonStart.setActionCommand("buttonStart");
		buttonStart.setBackground(new Color(255,255,255));
		buttonStart.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;				
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		buttonPanel.add(buttonStart,c);		
		
		// Creo il bottone di drop
		Icon drop = new ImageIcon("./img/drop.gif");
		buttonStop = new JButton(new InsetsIcon(drop));
		buttonStop.setRolloverEnabled(true);
		buttonStop.setToolTipText("Drop the message");
		buttonStop.setRolloverIcon(new ShadowedIcon(drop));
		buttonStop.setBorderPainted(false);
		buttonStop.setEnabled(false);		
		buttonStop.setPreferredSize(new Dimension(32,30));			
		buttonStop.setDisabledIcon(new ImageIcon("./img/dropDisabled.gif"));
		buttonStop.addActionListener(this);
		buttonStop.setActionCommand("buttonStop");
		buttonStop.setBackground(new Color(255,255,255));
		buttonStop.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		c = new GridBagConstraints();
		c.gridx = 1;
		c.gridy = 0;		
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		buttonPanel.add(buttonStop,c);
		
		// Creo la label per le info sulla richiesta
		infoProxy = new JLabel("");
		c = new GridBagConstraints();
		c.gridx = 2;
		c.gridy = 0;
		c.insets = new Insets(5,10,5,10);
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		buttonPanel.add(infoProxy,c);
		
		info = new JLabel("");	
		info.setPreferredSize(new Dimension(OptionControl.X-200,20));
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 6;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		buttonPanel.add(info,c);		
		
		// Creo il pannelo per la scelta della vista
		viewPanel = new JPanel(new GridBagLayout());	
		viewPanel.setBackground(new Color(255,255,255));
		
		ButtonGroup group = new ButtonGroup();		
		textView = new JRadioButton("Text");
		textView.setSelected(true);	
		textView.setActionCommand("text");
		textView.addActionListener(this);
		textView.setToolTipText("view / edit message as ASCII text");		
		textView.setBackground(new Color(255,255,255));
		group.add(textView);		
		hexView = new JRadioButton("Hex");
		hexView.setActionCommand("Hex");
		hexView.addActionListener(this);
		hexView.setToolTipText("view / edit message as binary hex code");
		hexView.setBackground(new Color(255,255,255));
		group.add(hexView);		
		parameterView = new JRadioButton("Params");			
		parameterView.setActionCommand("params");
		parameterView.addActionListener(this);
		parameterView.setToolTipText("view / edit parameters in advanced mode");		
		parameterView.setBackground(new Color(255,255,255));
		abilitaModificaParametri();
		group.add(parameterView);
				
		// Li aggiungo al pannello
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;		
		viewPanel.add(textView,c);
		
		c = new GridBagConstraints();
		c.gridx = 1;
		c.gridy = 0;		
		viewPanel.add(hexView,c);	
		
		c = new GridBagConstraints();
		c.gridx = 2;
		c.gridy = 0;		
		viewPanel.add(parameterView,c);
		
		// Aggiungo i vari componenti
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;	
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		panel.add(buttonPanel,c);
		
		c = new GridBagConstraints();
		c.gridx = 1;
		c.gridy = 0;	
		c.anchor = GridBagConstraints.FIRST_LINE_END;
		panel.add(viewPanel,c);
		
		// Aggiungo la textArea e la tableArea
		panelInteractiveArea.add(scrollTableArea,TableArea);
		panelInteractiveArea.add(panelTextArea,TextArea);
		panelInteractiveArea.add(panelTableParametersArea,parameterArea);
		changeToTextArea();		
	}
	
	/**
	 * Funzione che ritorna il testo modificato dall'utente. La funzione deve essere indipendente dalla vista,
	 * comunque ritorno sempre il testo della textArea, visto che è più semplice da ottenere, inoltre essendo le due viste
	 * (tabella e textArea) sempre sincronizzate, ritornare un valore o l'altro è lo stesso
	 * @return Il testo della richiesta, indipendentemente dalla vista
	 */
	public static String getTesto() {
		return currentRequest;
	}
	
	private void textHandle(DocumentEvent e) {
		BaseFrame.evidenziaTab();
		currentRequest = text.getText(); // Aggiorno il testo corrente		
		currentRequest = updateContentLength(currentRequest);
	}
	
	public String updateContentLength(String str) {
		if (str == null || str.equals("") || !OptionControl.updateClientContentLength)
			return str;		
		ElaborateHTMLHeader h = new ElaborateHTMLHeader(str);
		int length = h.getData().length();
		
		if (length == 0) { // Elimino il campo Content-Length nel caso non avessi body	        			
			str = str.replaceAll("Content-Length:.*(\r|\n)(\r|\n)","");	        			
		}
		else {
			if (str.toLowerCase().indexOf("content-length") >= 0) {
				str = str.replaceAll("Content-Length:.*","Content-Length: "+length);
			}
			else { // Aggiungo il campo alla richiesta
    			str = str.replaceAll("\r\n\r\n","\r\nContent-Length: "+length+"\r\n\r\n");
			}			
		}		
		return str;
	}
	
	public void insertUpdate(DocumentEvent e) {
		textHandle(e);
	}
	
	public void removeUpdate(DocumentEvent e) {
		textHandle(e);
	}
	
	public void changedUpdate(DocumentEvent e) {}
	
	public void actionPerformed(ActionEvent e) {		
		if (e.getSource() instanceof JButton) {
			if (e.getActionCommand() == "buttonStart") {
				// premuto button forward
				resetFirstTabWidget();
				decision = 1;					
				synchronized(BaseFrame.userDecision) {					
					BaseFrame.userDecision.notify();
				}	
			}
			else if (e.getActionCommand() == "addParam") {
				myModelParameters.addRow(new Object[] {myModelParameters.getRowCount(),parametersType[0],"name","value"});
				updateParametersTable();
			}
			else if (e.getActionCommand() == "delParam") {
				if (tableParameters.getSelectedRow() >= 0) { 
					myModelParameters.removeRow(tableParameters.getSelectedRow());
					updateParametersTable();
				}
			}
			else if (e.getActionCommand() == "buttonStop") {
				// premuto button drop
				resetFirstTabWidget();
				decision = 2;	
				
				synchronized(BaseFrame.userDecision) {					
					BaseFrame.userDecision.notify();
				}
			}
		}
		else if (e.getSource() instanceof JRadioButton) {			
			if (e.getActionCommand() == "text") {
				// premuto button text, visualizzo la textArea
				text.setText(currentRequest);
				changeToTextArea();				
			}
			else if (e.getActionCommand() == "Hex"){
				// premuto button hex, visualizzo la tabella				
				impostaRichiestaInTabella();
				changeToTableArea();				
			}
			else if (e.getActionCommand() == "params") {
				// premuto params, visualizzo la tabella dei parametri	
				impostaRichiestaInTabellaParametri();
				changeToTableParametersArea();							
			}
		}		
	}
	
	
	/**
	 * Prende in input la richiesta e riempie la tabella dei parametri
	 * @param req
	 */
	private void impostaRichiestaInTabellaParametri() {	
		currentRequest = updateContentLength(currentRequest);
		String req = new String(currentRequest);
		ElaborateHTMLHeader labelUrl = new ElaborateHTMLHeader(currentRequest);  
		labelAction.setText(labelUrl.getUrlFromClientRequest());
		ArrayList<String> param;
		String[] t = new String[2];
		String[] p;	
		int s,e;		
		ArrayList<String> pos = new ArrayList<String>(); // Indica la posizione in cui inizia e finisce la stringa del parametro trovata. Inizio e fine sono separati da una virgola
		myModelParameters.setRowCount(0);
		ElaborateHTMLHeader h = new ElaborateHTMLHeader(req);
		parPosition.clear();
		
		// Imposto i parametri dell'url
		param = h.getURLParameters(pos);		
		if (param != null) {
			for(int i=0;i<param.size();i++) {
				p = pos.get(i).split(",");						
				if (param.get(i).indexOf("=") >= 0) {
					int ss = param.get(i).indexOf("=");
					t[0] = param.get(i).substring(0,ss);
					t[1] = param.get(i).substring(ss+1,param.get(i).length());
				}			
				else {
					t[0] = param.get(i);
					t[1] = "";
				}
				t[0] = t[0].trim();
				t[1] = t[1].trim();
				
				// Memorizzo la posizione delle due stringhe
				s = (int)Long.parseLong(p[0]);
				e = s+t[0].length();
				parPosition.put(t[0]+i+"0",s+","+e);
				if (t.length < 2 || t[1] == null || t[1].equals("")) { // Non è presente il valore del parametro					
					if (param.get(i).endsWith("=")) {						
						e++;
					}
					parPosition.put(""+i+"1",e+","+e);
					myModelParameters.addRow(new Object[] {String.valueOf(myModelParameters.getRowCount()),parametersType[0],t[0],""});
				}	
				else {
					s = e+1;
					e = (int)Long.parseLong(p[1]);
					parPosition.put(t[1]+i+"1",s+","+e);									
					myModelParameters.addRow(new Object[] {String.valueOf(myModelParameters.getRowCount()),parametersType[0],t[0],t[1]});
				}
							
			}
		}		
		// Imposto i parametri del body
		param = h.getBodyParameters(pos);
		if (param != null) {
			for(int i=0;i<param.size();i++) {
				int kk = myModelParameters.getRowCount();
				p = pos.get(kk).split(",");						
				if (param.get(i).indexOf("=") >= 0) {
					int ss = param.get(i).indexOf("=");
					t[0] = param.get(i).substring(0,ss);
					t[1] = param.get(i).substring(ss+1,param.get(i).length());
				}			
				else {
					t[0] = param.get(i);
					t[1] = "";
				}
				t[0] = t[0].trim();
				t[1] = t[1].trim();
				
				// Memorizzo la posizione delle due stringhe
				s = (int)Long.parseLong(p[0]);
				e = s+t[0].length();
				parPosition.put(t[0]+kk+"0",s+","+e);
				if (t.length < 2 || t[1] == null || t[1].equals("")) { // Non è presente il valore del parametro					
					if (param.get(i).endsWith("=")) {						
						e++;
					}
					
					parPosition.put(""+kk+"1",e+","+e);
					myModelParameters.addRow(new Object[] {String.valueOf(myModelParameters.getRowCount()),parametersType[1],t[0],""});
				}	
				else {
					s = e+1;
					e = (int)Long.parseLong(p[1]);
					parPosition.put(t[1]+kk+"1",s+","+e);									
					myModelParameters.addRow(new Object[] {String.valueOf(myModelParameters.getRowCount()),parametersType[1],t[0],t[1]});
				}		
			}
		}		
		// Imposto i cookie
		param = h.getCookies(pos);
		if (param != null) {
			for(int i=0;i<param.size();i++) {
				int kk = myModelParameters.getRowCount();
				p = pos.get(kk).split(",");						
				if (param.get(i).indexOf("=") >= 0) {
					int ss = param.get(i).indexOf("=");
					t[0] = param.get(i).substring(0,ss);
					t[1] = param.get(i).substring(ss+1,param.get(i).length());
				}			
				else {
					t[0] = param.get(i);
					t[1] = "";
				}
				t[0] = t[0].trim();
				t[1] = t[1].trim();
				
				// Memorizzo la posizione delle due stringhe
				s = (int)Long.parseLong(p[0]);
				e = s+t[0].length();
				parPosition.put(t[0]+kk+"0",s+","+e);
				if (t.length < 2 || t[1] == null || t[1].equals("")) { // Non è presente il valore del parametro					
					if (param.get(i).endsWith("=")) {						
						e++;
					}
					
					parPosition.put(""+kk+"1",e+","+e);
					myModelParameters.addRow(new Object[] {String.valueOf(myModelParameters.getRowCount()),parametersType[2],t[0],""});
				}	
				else {
					s = e+1;
					e = (int)Long.parseLong(p[1]);
					parPosition.put(t[1]+kk+"1",s+","+e);									
					myModelParameters.addRow(new Object[] {String.valueOf(myModelParameters.getRowCount()),parametersType[2],t[0],t[1]});
				}		
			}
		}	
	}
	
	public static void abilitaModificaParametri() {
		myModelParameters.setRowCount(0);
		parameterView.setEnabled(OptionControl.parametersModifyEnabled);		
		if (parameterView.isSelected() && parameterView.isEnabled()) {
			parameterView.doClick(); // Visualizzo i parametri
		}
	}
	
	public static void abilitaModificaParametri(boolean v) {
		OptionControl.parametersModifyEnabled = v;
		tableParameters.setEnabled(OptionControl.parametersModifyEnabled);		
		paramsDel.setEnabled(OptionControl.parametersModifyEnabled);
		paramsAdd.setEnabled(OptionControl.parametersModifyEnabled);
		if (!OptionControl.parametersModifyEnabled)
			labelAction.setText("");
		abilitaModificaParametri();
	}
	
	private void resetFirstTabWidget() {
		if (!BaseFrame.isInteractive()) {
			return;
		}
		enableForward(false);
		enableDrop(false);	
		setInfoRequest("");
		clearRichiestaInTabella();
		BaseFrame.nonEvidenziaTab();
	}
	
	public static void deleteText() {
		if (!BaseFrame.isInteractive()) {
			return;
		}
		text.setText("");		
	}
	
	public JPanel getTab() {
		return panel;
	}
	
	public static void enableForward(boolean choice) {
		buttonStart.setEnabled(choice);
	}
	
	public static void enableDrop(boolean choice) {
		buttonStop.setEnabled(choice);
	}
	
	private void creaParametersArea() {
		panelTableParametersArea = new JPanel(new GridBagLayout());
		panelTableParametersArea.setOpaque(true);	
		
		parameterArea = new GridBagConstraints();
		parameterArea.gridx = 0;
		parameterArea.gridy = 0;
		parameterArea.weighty = 1.0;
		parameterArea.weightx = 1.0;
		parameterArea.gridwidth = 1;
		parameterArea.fill = GridBagConstraints.BOTH;				
		myModelParameters = new myTableParametersModel();
		myModelParameters.setDataVector(null,columnParametersNames);		
		tableParameters = new JTable(myModelParameters);		
		tableParameters.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ListSelectionModel rowSM = tableParameters.getSelectionModel();		
		rowSM.addListSelectionListener(new ListSelectionListener() {
		    public void valueChanged(ListSelectionEvent e) {		        
		        if (e.getValueIsAdjusting()) return;
		        ListSelectionModel lsm = (ListSelectionModel)e.getSource();
		        if (lsm.isSelectionEmpty()) {
		            return;
		        } else {
		        	// Aggiorno il parametro correntemente selezionato
		            int row = lsm.getMinSelectionIndex();
		            type  = (String)myModelParameters.getValueAt(row,1);
		            item  = (String)myModelParameters.getValueAt(row,2);
		            value = (String)myModelParameters.getValueAt(row,3);
		        }
		    }
		});				
		tableParameters.getModel().addTableModelListener(this);		
		tableParameters.setOpaque(true);
		tableParameters.setEnabled(true);
		tableParameters.setBackground(new Color(255,255,255));
		tableParameters.setAutoscrolls(true);				
		tableParameters.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		tableParameters.setToolTipText("Double click to edit the value");
		TableColumn sportColumn = tableParameters.getColumnModel().getColumn(1);
		JComboBox comboBox = new JComboBox();
		comboBox.setEditable(false);
		comboBox.setBackground(new Color(255,255,255));		
		comboBox.addItem(parametersType[0]);
		comboBox.addItem(parametersType[1]);
		comboBox.addItem(parametersType[2]);
		sportColumn.setCellEditor(new DefaultCellEditor(comboBox));		
		DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
		renderer.setToolTipText("Click for choosing the parameter's type");
		sportColumn.setCellRenderer(renderer);		
		sportColumn = tableParameters.getColumnModel().getColumn(0);
		renderer = new DefaultTableCellRenderer();
		renderer.setToolTipText("");		
		sportColumn.setCellRenderer(renderer);		
		TableColumn column = null;		
		column = tableParameters.getColumnModel().getColumn(0);
		column.setPreferredWidth(50);	
		column = tableParameters.getColumnModel().getColumn(1);
		column.setPreferredWidth(150);	
		column = tableParameters.getColumnModel().getColumn(2);
		column.setPreferredWidth(200);	
		column = tableParameters.getColumnModel().getColumn(3);
		column.setPreferredWidth(300);
		tableParameters.getModel().addTableModelListener(this);		
		scrollTableParametersArea=new JScrollPane(tableParameters);
		scrollTableParametersArea.setPreferredSize(new Dimension(500,300));		
		
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.fill = GridBagConstraints.BOTH;
		panelTableParametersArea.add(scrollTableParametersArea,c);
		
		// Creo la prate di interazione con i parametri
		panParamsBottom = new JPanel(new GridBagLayout());
		labelAction = new JLabel("");
				
		paramsAdd = new JButton(new ImageIcon("./img/addParams.gif"));
		paramsAdd.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		paramsAdd.setPreferredSize(new Dimension(16,16));
		paramsAdd.setMinimumSize(new Dimension(16,16));
		paramsAdd.setBorder(null);		
		paramsAdd.setRolloverIcon(new ImageIcon("./img/addParamsSel.gif"));		
		paramsAdd.setBackground(new Color(255,255,255));		
		paramsAdd.setToolTipText("Add a new parameter to the list");	
		paramsAdd.setActionCommand("addParam");
		paramsAdd.setEnabled(OptionControl.parametersModifyEnabled);
		paramsAdd.addActionListener(this);				
		
		paramsDel = new JButton(new ImageIcon("./img/delParams.gif"));
		paramsDel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		paramsDel.setPreferredSize(new Dimension(16,16));
		paramsDel.setMinimumSize(new Dimension(16,16));
		paramsDel.setBorder(null);
		paramsDel.setRolloverIcon(new ImageIcon("./img/delParamsSel.gif"));
		paramsDel.setBackground(new Color(255,255,255));
		paramsDel.setToolTipText("Delete the selected parameter from the list");	
		paramsDel.setActionCommand("delParam");
		paramsDel.setEnabled(OptionControl.parametersModifyEnabled);
		paramsDel.addActionListener(this);	
		
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;		
		c.anchor = GridBagConstraints.CENTER;
		panParamsBottom.add(new JLabel("Target: "),c);
		
		c = new GridBagConstraints();
		c.gridx = 1;
		c.gridy = 0;
		c.weightx = 1.0;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.anchor = GridBagConstraints.CENTER;
		panParamsBottom.add(labelAction,c);
		
		c = new GridBagConstraints();
		c.gridx = 2;
		c.gridy = 0;
		c.insets = new Insets(5,5,5,5);
		c.anchor = GridBagConstraints.FIRST_LINE_END;
		panParamsBottom.add(paramsAdd,c);
		
		c = new GridBagConstraints();
		c.gridx = 3;
		c.gridy = 0;
		c.insets = new Insets(5,5,5,5);		
		c.anchor = GridBagConstraints.FIRST_LINE_END;
		panParamsBottom.add(paramsDel,c);
		
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1.0;
		c.fill = GridBagConstraints.HORIZONTAL;
		panelTableParametersArea.add(panParamsBottom,c);
				
	}	
	
	private void creaTextArea() {
		// Creo la TextArea
		panelTextArea = new JPanel(new GridBagLayout());
		panelTextArea.setOpaque(true);		
		text = new JTextArea(10,40);		
		text.setOpaque(true);				
		scrollTextArea = new JScrollPane(text);
		scrollTextArea.setPreferredSize(new Dimension(500,300));		
		text.getDocument().addDocumentListener(this);
		search = new SearchField(text);
		
		TextArea = new GridBagConstraints();
		TextArea.gridx = 0;
		TextArea.gridy = 0;
		TextArea.weighty = 1.0;
		TextArea.weightx = 1.0;
		TextArea.gridwidth = 1;
		TextArea.fill = GridBagConstraints.BOTH;
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.fill = GridBagConstraints.BOTH;
		panelTextArea.add(scrollTextArea,c);
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 1;		
		c.weightx = 1.0;
		c.fill = GridBagConstraints.HORIZONTAL;
		panelTextArea.add(search.getPanel(),c);			
	}
	
		
	/**
	 * Aggiunge al pannello la text area
	 *
	 */
	public void changeToTextArea() {
		scrollTableArea.setVisible(false);
		panelTableParametersArea.setVisible(false);
		panelTextArea.setVisible(true);		
		if (currentCaretPosition < currentRequest.length()) {
			text.setCaretPosition(currentCaretPosition);
		}
		else {
			text.setCaretPosition(0);
		}		
	}
	
	public void changeToTableArea() {
		panelTextArea.setVisible(false);
		panelTableParametersArea.setVisible(false);
		scrollTableArea.setVisible(true);		
		currentCaretPosition = text.getCaretPosition();
		
	}
	
	public void changeToTableParametersArea() {
		scrollTableArea.setVisible(false);
		panelTextArea.setVisible(false);		
		panelTableParametersArea.setVisible(true);
		currentCaretPosition = text.getCaretPosition();
	}
		
	private void creaTableArea() {
		TableArea = new GridBagConstraints();
		TableArea.gridx = 0;
		TableArea.gridy = 0;
		TableArea.weighty = 1.0;
		TableArea.weightx = 1.0;
		TableArea.gridwidth = 1;
		TableArea.fill = GridBagConstraints.BOTH;
				
		myModel = new myTableModel();
		myModel.setDataVector(null,columnNames);		
		table = new JTable(myModel);	
		table.setOpaque(true);
		table.setEnabled(true);
		table.setBackground(new Color(255,255,255));
		table.setAutoscrolls(true);				
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);	
		table.getModel().addTableModelListener(this);
		scrollTableArea=new JScrollPane(table);
		scrollTableArea.setPreferredSize(new Dimension(500,300));		
		setColumnWidth();
		
	}
	
	private void updateParametersTable() {
		String urlParameters = "";
    	String bodyParameters = "";
    	String cookie = "";
    	int s,en;
    	
    	// Costruisco tutti i vari parametri
    	String tx;
    	String ix;
    	String vx;
    	String u = "";
    	String b = "";
    	String c = "";	  
    	
    	for (int j=0;j<myModelParameters.getRowCount();j++) {
    		tx = (String)myModelParameters.getValueAt(j,1);
    		ix = (String)myModelParameters.getValueAt(j,2);
    		vx = (String)myModelParameters.getValueAt(j,3);
    		
    		if (vx != null && !vx.equals("")) {
    			vx = '='+vx;
    		}
    		else {
    			vx = "";
    		}
    			            		
    		if (tx.equals(parametersType[0])) { // Url
    			if (u.equals("")) {
    				u = ix+vx;
    			}
    			else {
    				u = u+'&'+ix+vx;
    			}
    		}
    		else if (tx.equals(parametersType[1])) { // Body
    			if (b.equals("")) {
        			b = ix+vx;
    			}
    			else {
        			b = b+'&'+ix+vx;
    			}
    		}
    		else if (tx.equals(parametersType[2])) { // Cookie
    			if (c.equals("")) {
    				c = ix+vx;
    			}
    			else {
    				c = c+"; "+ix+vx;
    			}	            			
    		}
    	}
    	
    	// Modifico l'url
    	String regex = ".*\\?(.*) .*";
		Matcher mt;
		Pattern pt;
		pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		mt = pt.matcher(currentRequest);
		if (mt.find()) {	        			
			urlParameters = mt.group(1);
			s = mt.start(1);
			en = mt.end(1);
			if (currentRequest.charAt(s-1) == '?' && (u == null || u.equals("")))
				s--;
			currentRequest = new String (this.replace(currentRequest,u,s,en));
		}
		else { // Nessun parametro sull'url
			regex = " (.*) "; // Ottengo l'url
			pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
    		mt = pt.matcher(currentRequest);		        		
			if (mt.find()) {
				urlParameters = mt.group(1);
				s = mt.start(1);
    			en = mt.end(1);
    			if (u != null && !u.equals(""))		        				
    				currentRequest = new String (this.replace(currentRequest,urlParameters+"?"+u,s,en));
			}
		}
		
		// Modifico i cookie
		regex = "Cookie:(.*)$";
		pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE);
		mt = pt.matcher(currentRequest);
		if (mt.find()) {
			cookie = mt.group(1);
			s = mt.start(1);
			en = mt.end(1);
			currentRequest = new String (this.replace(currentRequest," "+c,s,en));
		}
		else {
			// Non è presente il campo Cookie: , se il valore non è vuoto lo aggiungo alla fine
			if (c != null && !c.equals(""))
				currentRequest = currentRequest.replaceAll("\r\n\r\n","\r\nCookie: "+c+"\r\n\r\n");	
		}
		
		// Modifico il body
		regex = "\r\n\r\n(.*)$";
		pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		mt = pt.matcher(currentRequest);
		if (mt.find()) {
			bodyParameters = mt.group(1);
			s = mt.start(1);
			en = mt.end(1);
			currentRequest = new String (this.replace(currentRequest,b,s,en));
		}
	
		if (c== null || c.equals("")) { // Elimino il campo cookie nel caso non ne avessi	        			
			currentRequest = currentRequest.replaceAll("Cookie:.*(\r|\n)(\r|\n)","");	        			
		}
		
    	impostaRichiestaInTabellaParametri();
	}
	
	 public void tableChanged(TableModelEvent e) {		 
		 	int row = e.getFirstRow();		 	
	        int column = e.getColumn();	       
	        if (column == -1) {
	        	return;
	        }	        
	        TableModel model = (TableModel)e.getSource();	
	        if (model instanceof myTableModel) {	        	
	        	// Evento nella tabella esadecimale
	        	int posCarattere = row*NUMCOLTABLE+column-1;
	        
	        	int oldlIntDato = (int)currentRequest.charAt(posCarattere);
	        	String oldDato = Integer.toHexString(oldlIntDato);
	        
	        	String newDato = (String)model.getValueAt(row, column);   
	        	Integer newIntDato = -1; // Valore errato
	        
	        	try {
	        		newIntDato = Integer.decode("0x"+newDato);
	        	}
	        	catch (NumberFormatException i) {BaseFrame.message("Invalid HEX code","Error",JOptionPane.ERROR_MESSAGE);}
	        
	        
	        	if (newIntDato.intValue() > 255 || newIntDato.intValue() < 0) { // numero non valido
	        		table.getModel().removeTableModelListener(this);
	        		model.setValueAt(oldDato,row,column);	        	
	        		table.getModel().addTableModelListener(this);
	        	}
	        	else {
	        		// Modifico la stringa della richiesta corrente
	        		char[] tmp = currentRequest.toCharArray();
	        		tmp[posCarattere] = (char)newIntDato.intValue();
	        		currentRequest = String.valueOf(tmp);
	        		        	
	        		// Modifico il valore visualizzato nell'utlima colonna
	        		String lastCol = (String)model.getValueAt(row,17); // Ottengo il valore
	        		tmp = lastCol.toCharArray();
	        		tmp[column-1] = (char)newIntDato.intValue();
	        		lastCol = String.valueOf(tmp);
	        		table.getModel().removeTableModelListener(this);
	        		model.setValueAt((String)lastCol,row,17);
	        		impostaRichiestaInTabella();
	        		table.getModel().addTableModelListener(this);	        		
	        	}	
	        }
	        else if (model instanceof myTableParametersModel) {
	        	// Evento nella tabelle dei parametri	        	
	            model = (TableModel)e.getSource();
	            String t = (String)model.getValueAt(row, 1);
	        	
	        	if (column == 1 && !type.equals(t)) {
	            	tableParameters.getModel().removeTableModelListener(this);
	            	updateParametersTable();
	            	tableParameters.getModel().addTableModelListener(this);	            	
	            	return;
	            }	
	        		        	
	            String i = (String)model.getValueAt(row, 2);
	            String v = (String)model.getValueAt(row, 3);
	            int s,en;
	            if (OptionControl.doParametersUrlCompliant) {	            	
	            	i = escapeChar(i);
	            	v = escapeChar(v);
	            }
	            
	            if (t.equals(parametersType[0])) {
	            	// Parametro dell'url	            					
					String[] p;					
					if (column == 2 && parPosition.containsKey(item+row+"0")) {
						p = parPosition.get(item+row+"0").split(",");
						s = (int)Long.parseLong(p[0]);
						en = (int)Long.parseLong(p[1]);
						currentRequest = new String(this.replace(currentRequest,i,s,en));
						en = i.length();
						parPosition.remove(item+row+"0");
						parPosition.put(i+row+"0",s+","+en);
					}
					else if (column == 3 && parPosition.containsKey(value+row+"1")) {
						p = parPosition.get(value+row+"1").split(",");
						s = (int)Long.parseLong((String)p[0]);
						en = (int)Long.parseLong((String)p[1]);
						if (currentRequest.charAt(s-1) != '=' && v != null && !v.equals("")) {
							currentRequest = new String (this.replace(currentRequest,"="+v,s,en));
						}
						else {
							currentRequest = new String (this.replace(currentRequest,v,s,en));
						}						
						en = v.length();
						parPosition.remove(value+row+"1");
						parPosition.put(v+row+"1",s+","+en);
					}   
					impostaRichiestaInTabellaParametri();
	            }
	            else if (t.equals(parametersType[1])) {
	            	// Parametro del body          					
					String[] p;					
					if (column == 2 && parPosition.containsKey(item+row+"0")) {
						p = parPosition.get(item+row+"0").split(",");
						s = (int)Long.parseLong(p[0]);
						en = (int)Long.parseLong(p[1]);
						currentRequest = new String(this.replace(currentRequest,i,s,en));
						en = i.length();
						parPosition.remove(item+row+"0");
						parPosition.put(i+row+"0",s+","+en);
					}
					else if (column == 3 && parPosition.containsKey(value+row+"1")) {
						p = parPosition.get(value+row+"1").split(",");
						s = (int)Long.parseLong((String)p[0]);
						en = (int)Long.parseLong((String)p[1]);
						if (currentRequest.charAt(s-1) != '=' && currentRequest.charAt(s-1) != '\n' && currentRequest.charAt(s-1) != '\r' && v != null && !v.equals("")) {
							currentRequest = new String (this.replace(currentRequest,"="+v,s,en));
						}
						else {
							currentRequest = new String (this.replace(currentRequest,v,s,en));
						}	
						en = v.length();
						parPosition.remove(value+row+"1");
						parPosition.put(v+row+"1",s+","+en);
					}  					
					impostaRichiestaInTabellaParametri();            	
	            	
	            }
	            else if (t.equals(parametersType[2])) {
	            	// cookie
	            	String[] p;					
					if (column == 2 && parPosition.containsKey(item+row+"0")) {
						p = parPosition.get(item+row+"0").split(",");
						s = (int)Long.parseLong(p[0]);
						en = (int)Long.parseLong(p[1]);
						currentRequest = new String(this.replace(currentRequest," "+i,s,en));
						en = i.length();
						parPosition.remove(item+row+"0");
						parPosition.put(i+row+"0",s+","+en);
					}
					else if (column == 3 && parPosition.containsKey(value+row+"1")) {
						p = parPosition.get(value+row+"1").split(",");
						s = (int)Long.parseLong((String)p[0]);
						en = (int)Long.parseLong((String)p[1])+1;
						if (currentRequest.charAt(s-1) != '=' && v != null && !v.equals("")) {
							currentRequest = new String (this.replace(currentRequest,"="+v,s,en));
						}
						else {
							currentRequest = new String (this.replace(currentRequest,v,s,en));
						}
						en = v.length();
						parPosition.remove(value+row+"1");
						parPosition.put(v+row+"1",s+","+en);
					}  					
					impostaRichiestaInTabellaParametri();            	
	            	
	            }
	        }
	 }
	 
	 /**
	  * Prende in input una stringa e gli sostituisce i rispettivi valori decodificati
	  * @param i
	  * @return
	  */
	 private String escapeChar(String i) {
		 if (i == null || i.equals(""))
			 return i;
 		 String result = ""; 		
 		 try {
 		      result = URLEncoder.encode(i, "UTF-8");
 		 }
 		 catch (UnsupportedEncodingException ex){
 		      System.out.println("UTF-8 not supported");
 		      return i;
 		 }
 		 if (!i.equals(result)) {
 			 // Ho apportato delle modifiche
 			 if (currentRequest.toLowerCase().indexOf("content-type") < 0) {
 				 // Aggiungo il content-type
 				 currentRequest = currentRequest.replaceAll("\r\n\r\n","\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\n");
 			 }
 		 } 		 
 		 
 		 return result; 		 
	 }
	
	
	 /**
	  * Sostituisce la stringa definita dai margini passati 'e' ed 's' di S con la stringa S1.
	  * @param S sottoStringa di rimpiazzo
	  * @param S1 Stringa da rimpiazzare
	  * @param s Punto in cui cominciare a sostituire
	  * @param e Punto in cui finire la sostituzione
	  * @return La stringa creata
	  */
	 private String replace(String S, String S1, int s, int e) {		
     	String foo;
     	String a,b;
     	a = S.substring(0,s);
     	b = S.substring(e,S.length());
     	foo = a+S1+b;     	
     	return foo;
	 }
	 
	 
	private void setColumnWidth() {
		// imposto la dimensione delle colonne
		TableColumn column = null;		
		column = table.getColumnModel().getColumn(0);
		column.setPreferredWidth(50);	
		column = table.getColumnModel().getColumn(1);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(2);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(3);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(4);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(5);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(6);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(7);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(8);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(9);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(10);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(11);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(12);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(13);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(14);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(15);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(16);
		column.setPreferredWidth(30);
		column = table.getColumnModel().getColumn(17);
		column.setPreferredWidth(170);		
		
	}
	
}

class myTableModel extends DefaultTableModel {	
		private int lastEditableRow = 0;
		private int lastEditableCol = 0;
		
        public boolean isCellEditable(int row, int col) {
        	lastEditableRow = this.getRowCount()-1;       	
        	if (col > 0 && col < 17) {        		
        		if (row < lastEditableRow) {
        			return true;
        		}
        		else if (row == lastEditableRow && col > lastEditableCol) {        			
        			return false;
        		}
        		else if (row > lastEditableRow) {
        			return false;
        		}        		
        		return true;
        	}            	
            return false;
        }
        
        public void setLastCellEditable(int c) {
        	lastEditableCol = c;
        }
		
}

class myTableParametersModel extends DefaultTableModel {
	 public boolean isCellEditable(int row, int col) {		        	    	
     	if (col > 0) {  // Prime due colonne non editabili      		
     		return true;
     	}            	
     	return false;
  }
}
