import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import javax.net.ssl.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

/**
 * Gestisce la coda delle richieste
 * @author s4tan
 *
 */

public class SchedulerRequest extends Thread{
	public static ArrayList requests;
	private modifyRequest modifier;
	private thirdTab tab2;
	private final int MAXBUFFLEN = 20000;	
	private Connection conn;
	private static BufferedWriter bw;
	private static boolean statusBF = false; // Chiuso
	
	SchedulerRequest() {
		requests = new ArrayList();
		tab2 = new thirdTab();		
	}
	
	/**
	 * Serve le richieste presenti in modo ciclico
	 * Controlla sempre se vi sono nuove richieste da servire
	 *
	 */
	public void run() {
		int indice = 0;
		Object obj;	
		MessageList.initialize();
		while(true) {
			while(requests.size() > 0) { // Fino a quando ho richieste le servo
				synchronized(requests) {	
					obj =requests.remove(0);	
				}				
				if (obj instanceof infoRichiesta) {
					BaseFrame.setChoiceInHystoryQueque(thirdTab.PROCESSING,indice,2);
					infoRichiesta foo = (infoRichiesta)obj;										
					conn = foo.getConnection();		
					Message msg = new Message();					
					MessageList.addMessage(msg);
					msg.setRequest(foo.getHeader());					
															
					// Modifico la richiesta del client
					modifier = new modifyRequest(foo.getHeader(),"Request to: "+foo.getHostServer()+":"+foo.getPortServer()+" [from: "+foo.getHostHost()+":"+foo.getPortHost()+"]");					
					if (foo.isSSL()) {
						modifier.setSSL(true); // Imposto il tipo di connesione (SSL oppure no)						
					}
					String newHeader = modifier.getModifiedRequest();	
					msg.setModifiedRequest(newHeader);
					// Controllo se è stata droppata la connessione
					if (modifier.isRequestDropped()) {
						// Droppo la connessione						
						BaseFrame.setChoiceInHystoryQueque(thirdTab.DROP,indice,2);
						BaseFrame.setChoiceInHystoryQueque("",indice,11);	
						indice++;
						conn.dropConnection();							
						break;
					}
					
					// Ottengo le informazioni dalla richiesta del client per aggoirnare la tabella dei messaggi						
					ElaborateHTMLHeader h = new ElaborateHTMLHeader(newHeader);
					// Controllo se devo aggiustare la lunghezza della richiesta
					if (OptionControl.updateClientContentLength) {
						newHeader = h.getUpdateHeaderLength();
						h = new ElaborateHTMLHeader(newHeader); // Ricreo l'oggetto con la lunghezza aggiornata
					}
					// Controllo se devo loggare le richieste tenendo conto delle altre opzioni
					if (OptionControl.logClientRequestToFile && modifyRequest.showRequest) {
						Date data = new Date(System.currentTimeMillis());
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data);
						String tempo = calendar.get(Calendar.HOUR_OF_DAY)+":"+calendar.get(Calendar.MINUTE)+":"+calendar.get(Calendar.SECOND);
						String date  = calendar.get(Calendar.DAY_OF_MONTH)+"/"+calendar.get(Calendar.MONTH)+"/"+calendar.get((Calendar.YEAR));
						saveLog(newHeader,"| "+date+" "+tempo+" Request to: "+foo.getHostServer()+":"+foo.getPortServer()+" [from: "+foo.getHostHost()+":"+foo.getPortHost()+"] |");
					}					
					BaseFrame.setChoiceInHystoryQueque(h.getUrlFromClientRequest(),indice,5); // setto l'url eventualmente modificato
					BaseFrame.setChoiceInHystoryQueque(h.getMethod(),indice,8); // setto il metodo eventualmente modificato
					BaseFrame.setChoiceInHystoryQueque(h.getTypeFileFromClientRequest(),indice,9); // setto il tipo di file
					BaseFrame.setChoiceInHystoryQueque(h.getData(),indice,13); // setto i dati del client
										
					// Imposto la decisione presa (forworded)
					BaseFrame.setChoiceInHystoryQueque(thirdTab.FORWARDER,indice,2);
					
					// Invio la richiesta al server ed aspetto la risposta					
					newHeader = invioRichiesta(newHeader,foo.getHostServer(),foo.getPortServer(),foo.isSSL());
					msg.setResponse(newHeader);
					BaseFrame.setChoiceInHystoryQueque(thirdTab.PROCESSING,indice,11);					
					// Viene esaminato l'header originale ricevuto dal server
					h = new ElaborateHTMLHeader(newHeader);				
					// Imposto le informazioni ricevute dal server						
					BaseFrame.setChoiceInHystoryQueque(h.getStatusFromServerResponse(),indice,10);
					BaseFrame.setChoiceInHystoryQueque(h.getLengthFromServerResponse(),indice,12);
					BaseFrame.setChoiceInHystoryQueque(h.getCookieFromServerResponse(),indice,14);						
					
					// Modifico la richiesta del server e la inoltro al browser
					modifier = new modifyRequest(newHeader,"Response from: "+foo.getHostServer()+":"+foo.getPortServer()+" [to: "+foo.getHostHost()+":"+foo.getPortHost()+"]");					
					modifier.setSSL(foo.isSSL()); // Imposto il tipo di connesione (SSL oppure no)		
					String newResponse = modifier.getModifiedResponse();
					msg.setModifiedResponse(newResponse);
					//	Controllo se è stata droppata la connessione
					if (modifier.isResponsesDropped()) {						
						BaseFrame.setChoiceInHystoryQueque(thirdTab.DROP,indice,11);
						// Droppo la connessione
						conn.dropConnection();	
						indice++;
						break;
					}
														
					// Ottengo le informazioni ricevute dal server per aggiornare la tabella dei messaggi				
					h = new ElaborateHTMLHeader(newResponse);	
					// Controllo se devo aggiornare la lunghezza della risposta
					if (OptionControl.updateServerContentLength) {
						newResponse = h.getUpdateHeaderLength();
						h = new ElaborateHTMLHeader(newResponse); // Ricreo l'oggetto con la lunghezza aggiornata
					}
					// Controllo se devo loggare le risposte tenendo conto delle altre opzioni					
					if (OptionControl.logClientRequestToFile && OptionControl.logServerResponseToFile && modifyRequest.showResponse) {
						Date data = new Date(System.currentTimeMillis());
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data);
						String tempo = calendar.get(Calendar.HOUR_OF_DAY)+":"+calendar.get(Calendar.MINUTE)+":"+calendar.get(Calendar.SECOND);
						String date  = calendar.get(Calendar.DAY_OF_MONTH)+"/"+calendar.get(Calendar.MONTH)+"/"+calendar.get((Calendar.YEAR));						
						saveLog(newResponse,"| "+date+" "+tempo+" Response from: "+foo.getHostServer()+":"+foo.getPortServer()+" [to: "+foo.getHostHost()+":"+foo.getPortHost()+"] |");
					}
					// Imposto le informazioni ricevute dal server					
					BaseFrame.setChoiceInHystoryQueque(h.getStatusFromServerResponse(),indice,10);
					BaseFrame.setChoiceInHystoryQueque(h.getLengthFromServerResponse(),indice,12);
					BaseFrame.setChoiceInHystoryQueque(h.getCookieFromServerResponse(),indice,14);
					BaseFrame.setChoiceInHystoryQueque(thirdTab.FORWARDER,indice,11);
					
					indice++;
					conn.forwardResponse(newResponse);	// Invio la risposta al client					
				}
			} // End while gestisci richieste (Non ho nessuna richiesta in coda)			
			// Attendo altre richieste
			synchronized(requests) {	
				if (requests.size() <= 0) {
					try {
						requests.wait();
					}
					catch(InterruptedException ignored) {}
				}			
			}						
		}
	}
	
	/**
	 * Aggiungo la richiesta alla coda
	 * @param req
	 */
	public synchronized static void addRequest(infoRichiesta req) {
		BaseFrame.addVoiceRequest(req);
		requests.add(req);		
	}

	/**
	 * Ha il compito di salvare le richieste sul file di log.
	 * @param prende in ingresso la richiesta che sarà accodata al file di log
	 * @param prende in ingresso un'eventuale header che sarà inserito prima della richiesta. Il suo compito è quello di fornire
	 * informazioni circa la richiesta che si è loggata
	 */
	private static void saveLog(String req, String head) {
		if (statusBF == false) { // Stream chiuso
			return;
		}
		try {					
			if (!head.equals("")) {
				// Creo la stringa header
				String lineaH = "+";
				for(int i=0;i<head.length()-2;i++) {
					lineaH = lineaH+"-";
				}		
				lineaH = lineaH+"+";
				bw.newLine();							
				bw.write(lineaH);
				bw.newLine();
				bw.write(head);
				bw.newLine();			
				bw.write(lineaH);
				bw.newLine();
			}				
			bw.write(req);			
		}
		catch(IOException ignored) {ignored.printStackTrace();}		
	}
	
	/**
	 * Ha il compito di chiudere il file di log generato
	 *
	 */
	public static void closeLog() {		
		if (statusBF == false) { // Stream già chiuso			
			return;
		}
		Date data = new Date(System.currentTimeMillis());
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(data);
		String tempo = calendar.get(Calendar.HOUR_OF_DAY)+":"+calendar.get(Calendar.MINUTE)+":"+calendar.get(Calendar.SECOND);
		String date  = calendar.get(Calendar.DAY_OF_MONTH)+"/"+calendar.get(Calendar.MONTH)+"/"+calendar.get((Calendar.YEAR));
		String scritta = "EvilProxy End logging: "+date+ " Time: "+tempo;
		String linea = "";
		for(int i=0;i<scritta.length();i++) {
			linea = linea+"=";
		}		
		try {	
			bw.newLine();
			bw.write(linea);
			bw.newLine();
			bw.write(scritta);
			bw.newLine();
			bw.write(linea);
			bw.newLine();
			bw.flush();
			bw.close();
		}
		catch(IOException ignored) {ignored.printStackTrace();}	
		statusBF = false;
	}
	
	/**
	 * Ha il compito di creare (e ricreare) il file di log
	 *
	 */	
	public static int createLog() {	
		Date data = new Date(System.currentTimeMillis());
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(data);
		String tempo = calendar.get(Calendar.HOUR_OF_DAY)+":"+calendar.get(Calendar.MINUTE)+":"+calendar.get(Calendar.SECOND);
		String date  = calendar.get(Calendar.DAY_OF_MONTH)+"/"+calendar.get(Calendar.MONTH)+"/"+calendar.get((Calendar.YEAR));
		String scritta = "EvilProxy Start logging: "+date+ " Time: "+tempo;
		String linea = "";
		for(int i=0;i<scritta.length();i++) {
			linea = linea+"=";
		}		
		// Creo il fileWriter
		try {
			FileWriter fw = new FileWriter(OptionControl.filenameLogRequests);			
			bw = new BufferedWriter(fw);			
			bw.write(linea);
			bw.newLine();
			bw.write(scritta);
			bw.newLine();
			bw.write(linea);
			bw.newLine();	
			bw.newLine();
			bw.flush();
		}
		catch (java.io.FileNotFoundException ignored) {return -1;}
		catch(IOException ignored) {ignored.printStackTrace(); return -1;}
		statusBF = true; // Stream aperto
		return 0;
	}
	
	/**
	 * Invia la richiesta e aspetta una risposta
	 * @param url
	 * @param header
	 * @return
	 */
	private String invioRichiesta(String header, String host, int port, boolean ssl) {		
		BufferedWriter writerToServer = null;
		
		// Creo il socket
		Socket cliente = null;	
		SSLSocket SSLClient = null;		
		try {
			if (OptionControl.isSetProxy()) { // è impostato il proxy
				cliente = new Socket(OptionControl.getProxyHost(),OptionControl.getProxyPort());					
				cliente.setSoTimeout(OptionControl.TIMEOUTPROXY);
			}
			else {
				if (ssl) {
					
				}
				else {
					cliente = new Socket(host,port);
					cliente.setSoTimeout(OptionControl.TIMEOUT);
				}						
			}						
		}
		catch(IOException e) {		
			if (BaseFrame.isInteractive()) {
				JOptionPane.showMessageDialog(null,"Unable to open URL "+host+":"+port+".\nPlease check the URL and try again.","Error",JOptionPane.ERROR_MESSAGE);
			}			
			return "<h1><b>Error:</b> Unable to open URL "+host+":"+port+", please check the url and try again.<h1><h3>Powered by <i>evilproxy</i></h3>";	
		}			
		// Invio la richiesta del browser
		try {
			writerToServer = new BufferedWriter(new OutputStreamWriter(cliente.getOutputStream()));
			writerToServer.write(header);
			writerToServer.flush();			
		}		
		catch (IOException ignored) {}		
		
		// Leggo la risposta del server
		String response = "";
		try {
			HTTPMessageReader msg = new HTTPMessageReader(cliente,MAXBUFFLEN);	
			response = msg.readHeader();
			HttpBody body;		
			ElaborateHTMLHeader h = new ElaborateHTMLHeader(response);	
			if (mustReadBody(h.getStatusFromServerResponse())) {
				if (OptionControl.ungunzipResponse && h.encoding().toLowerCase().equals("gzip") && OptionControl.isInteractive && OptionControl.interceptServerResponse) { // Decomprimo il contenuto
					response = msg.readZippedBody().toString(); // Ottengo il contenuto unzippato					
				}
				else {
					body = msg.readBody();
					response = response + body.toString();
				}						
				
			}
		}
		catch(IOException ignored) {}
	
		try {
			writerToServer.close();			
			cliente.close();
		}	
		catch(IOException ignored) {ignored.printStackTrace();}	
		return response;
	}
	
	/**
	 * Esamina lo status code e mi dice se è presente il body
	 * @param c
	 * @return
	 */
	private boolean mustReadBody(String c) {
		String regex = "^\\d*?$";
		int code = -1;
		boolean status = true;
		if (c != null && Pattern.matches(regex,c)) { // Ricavo la porta						
			code = (int)Long.parseLong(c);						
		}
		if (code > 0) {
			switch (code) {
			case 304: 
				status = false;	
				break;
			}
		}
		return status;
	}
}
