import javax.swing.*;
import java.awt.*;
import javax.swing.table.TableColumn;
import javax.swing.table.DefaultTableModel;
import java.util.Date;
import java.util.Calendar;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

/**
 * Tab per la visualizzazione delle richieste in coda
 * @author s4tan
 */
public class thirdTab implements MouseListener{
	private JPanel panel;
	private JTable table;
	private myTableModelThirdTab myModel;	
	public final static int DROP = 0;
	public final static int FORWARDER = 1;
	public final static int QUEQUE = 2;
	public final static int PROCESSING = 3;
	private final String _DROP = "Dropped";
	private final String _FORWARDED = "Forwarded";
	private final String _QUEQUE = "In Queque";
	private final String _PROCESSING = "Processing";
	private final String[] decisioni = {_DROP,_FORWARDED,_QUEQUE,_PROCESSING};
	
	
	private String[] columnNames = {"#","Time","Info Request","Source Address","Source Port","Url","Destination Address","Destination Port","Method","Type","Status","Info Response","Server Data Length","Client Data","Cookies","SSL"};
		
	thirdTab() {
		panel = new JPanel(new GridBagLayout());
		panel.setBackground(new Color(255,255,255));
		myModel = new myTableModelThirdTab();
		myModel.setDataVector(null,columnNames);
		table = new JTable(myModel);		
		table.setToolTipText("Double-click an item for more details");
		table.addMouseListener(this);        
		table.setBackground(new Color(255,255,255));
		table.setAutoscrolls(true);			
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);		   
	 	
    	// imposto la dimensione delle colonne
		TableColumn column = null;	
		column = table.getColumnModel().getColumn(0);
		column.setPreferredWidth(50);
		column = table.getColumnModel().getColumn(1);
		column.setPreferredWidth(70);
		column = table.getColumnModel().getColumn(2);
		column.setPreferredWidth(100);
		column = table.getColumnModel().getColumn(3);
		column.setPreferredWidth(100);
		column = table.getColumnModel().getColumn(4);
		column.setPreferredWidth(100);
		column = table.getColumnModel().getColumn(5);
		column.setPreferredWidth(250);
		column = table.getColumnModel().getColumn(6);
		column.setPreferredWidth(130);
		column = table.getColumnModel().getColumn(7);
		column.setPreferredWidth(100);
		column = table.getColumnModel().getColumn(8);
		column.setPreferredWidth(100);
		column = table.getColumnModel().getColumn(11);
		column.setPreferredWidth(120);
		column = table.getColumnModel().getColumn(12);
		column.setPreferredWidth(120);
	
		JScrollPane scrollTable = new JScrollPane(table);		
		scrollTable.setPreferredSize(new Dimension(500,310));		
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.weighty = 1.0;
		c.weightx = 1.0;
		c.fill = GridBagConstraints.BOTH;
		panel.add(scrollTable,c);		
	}
	
	public void mousePressed(MouseEvent e) { }

	public void mouseReleased(MouseEvent e) {}

	public void mouseEntered(MouseEvent e) { }

	public void mouseExited(MouseEvent e) { }

	public void mouseClicked(MouseEvent e) {
	  if (e.getClickCount() >= 2){
		  JTable table = (JTable)e.getSource();		  
		  myTableModelThirdTab m = (myTableModelThirdTab)table.getModel();		  
		  MessageList.showMessage(table.getSelectedRow(),"Request for: "+(String)m.getValueAt(table.getSelectedRow(),5));
	  }

	}	   
	
	public void addVoice(infoRichiesta  v) {
		Date data = new Date(System.currentTimeMillis());
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(data);
		String temppoArrivo = calendar.get(Calendar.HOUR_OF_DAY)+":"+calendar.get(Calendar.MINUTE)+":"+calendar.get(Calendar.SECOND);
		
		myModel.insertRow(myModel.getRowCount(), new Object[]{
			String.valueOf(myModel.getRowCount()),
			temppoArrivo,
			decisioni[2],
			v.getHostHost(),
			String.valueOf(v.getPortHost()),
			v.getUrl(),
			v.getHostServer(),
			String.valueOf(v.getPortServer()),
			v.getMethod(),
			"",
			"",
			decisioni[2],"","","",new Boolean(v.isSSL())});
		// Imposto il tipo di file
		ElaborateHTMLHeader h = new ElaborateHTMLHeader(v.getHeader());
		BaseFrame.setChoiceInHystoryQueque(h.getTypeFileFromClientRequest(),myModel.getRowCount()-1,9);
		BaseFrame.setChoiceInHystoryQueque(h.getData(),myModel.getRowCount()-1,13);
		
	}	
	
	/**
	 * Funzione per impostare l'azione presa rispetto ad una richiesta nella tablle delle history
	 * @param choice
	 * @param col
	 */
	public void setChoice(int choice, int row, int col) {
		String v;
		if (choice == 1) {
			v = "<html><body><b>"+decisioni[choice]+"</b></html></body>";
		}
		else if (choice == 0) {
			v = "<html><body><b><i>"+decisioni[choice]+"</b></i></html></body>";
		}
		else if (choice == 3) {
			v = "<html><body><i>"+decisioni[choice]+"</i></html></body>";
		}
		else {
			v = decisioni[choice];
		}
		myModel.setValueAt(v,row,col);		
	}
	
	public void setChoice(String choice, int row, int col) {
		myModel.setValueAt(choice,row,col);		
	}
	
	public void setChoice(Object choice, int row, int col) {
		myModel.setValueAt(choice,row,col);		
	}
	
	public JPanel getTab() {
		return panel;
	}
}

class myTableModelThirdTab extends DefaultTableModel {		
    public boolean isCellEditable(int row, int col) {    	
        return false;
    }    	
    
    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();    	
    }  
}