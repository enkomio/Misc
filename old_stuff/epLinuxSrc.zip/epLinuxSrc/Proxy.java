import java.net.ServerSocket;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import javax.swing.*;

/**
 * Accetta una connessione, avvia il relativo thread e ritorna ad ascoltare
 * @author s4tan, s4tan@ictsc.it
 */
public class Proxy extends Thread{
	private static ServerSocket server;	
	private final String localhost = OptionControl.hostEvilProxy;	// Identifica l'host
	private final int localport = OptionControl.portEvilProxy;		// Identifica la porta
	private final int MAXNUMCONNECTION = 10;	
	private SchedulerRequest scheduler;	 
	private static Integer attivaServer = new Integer(0);
	
	Proxy() {
		init();		
	}
	
	Proxy(int p) {
		init();	
		setPort(p);
	}
	
	Proxy(String h) {
		init();	
		setHost(h);
	}
	
	Proxy(String h, int p) {
		init();
		setPort(p);
		setHost(h);		
	}
	
	private void init() {
		setPort(localport);
		setHost(localhost);	
	}
	
	public void setPort(int p) {
		if (p > 0 && p < 65535) {
			OptionControl.portEvilProxy = p;			
		}		
	}
	
	public void setHost(String h) {
		if (h != null && h != "") {
			OptionControl.hostEvilProxy = h;
		}
	}
	
	public int getPort() {
		return OptionControl.portEvilProxy;
	}
	
	public String getHost() {
		return OptionControl.hostEvilProxy;
	}
	
	/**
	 * Mi indica se il server proxy è stato avviato con successo oppure no
	 * @return
	 */
	public boolean serverIsOn() {
		return OptionControl.isServerOn;
	}
		
	/**
	 * Funzione di avvio del server
	 *
	 */
	public void run() {
		try {
			server = new ServerSocket(getPort(),MAXNUMCONNECTION);
			server.setSoTimeout(OptionControl.TIMEOUT);
			OptionControl.isServerOn = true;
		}
		catch(IOException e) {
			if (BaseFrame.isInteractive()) {
				JOptionPane.showMessageDialog(null,"Unable to open port "+getPort()+".\nThis port may be in use by another application.\nPlease select a differnet port, restart the proxy server and adjust your browser settings.","Error",JOptionPane.ERROR_MESSAGE);
			}
			OptionControl.isServerOn = false;			
		}		
		// Avvio lo scheduler
		avviaScheduler();		
		// Comincio ad accettare richieste		
		this.accept();		
	}
	
	/**
	 * Crea e avvia lo sheduler
	 *
	 */
	private void avviaScheduler() {
		scheduler = new SchedulerRequest();
		scheduler.start(); // avvio lo scheduler
	}
	
	/**
	 * Ferma il server proxy, ovvero non accetto più richieste
	 *
	 */
	public void stopServer() {		
		if (serverIsOn()) {
			try {			
				server.close();
				OptionControl.isServerOn = false;
			}
			catch(IOException e) {}			
		}
	}
	
	/**
	 * Fa ripartire il server
	 *
	 */
	public void startServer() {
		try {			
			server = new ServerSocket(OptionControl.portEvilProxy,MAXNUMCONNECTION);
			server.setSoTimeout(OptionControl.TIMEOUT);
			OptionControl.isServerOn = true;
		}
		catch(IOException e) {
			if (BaseFrame.isInteractive()) {
				JOptionPane.showMessageDialog(null,"Unable to open port "+getPort()+".\nThis port may be in use by another application.\nPlease select a differnet port, restart the proxy server and adjust your browser settings.","Error",JOptionPane.ERROR_MESSAGE);
			}
			OptionControl.isServerOn = false;
			return;
		}
		synchronized(attivaServer) {
			attivaServer.notify();
		}		
	}
	
	
	private void accept() {			
		while(true) {			
			if(OptionControl.isServerOn) {
				attivaServer = new Integer(1);
			}
			else {
				attivaServer = new Integer(0);
			}
			synchronized(attivaServer) {
				if (attivaServer.intValue() == 0) {
					try {
						attivaServer.wait();
					}
					catch(InterruptedException ignored) {}
				}
			}	
			if (server != null) {
				try {				
					Socket client = server.accept();	
					Connection connessione = new Connection(client);
					connessione.start();	
				}
				catch (SocketTimeoutException ignored) {}
				catch (IOException ignored) {}
			}
		}
	}
}
