import java.util.ArrayList;
import java.util.Arrays;

/**
 * Classe per la gestione delle opzioni di burpproxy
 * @author s4tan
 *
 */
public class OptionControl {
	private boolean isRequestAutomaticModified = false;
	
	// Variabili di configurazione dell'applicazione
	public static int portEvilProxy = 8080;					// Porta su cui rimanere in ascolto
	public static String hostEvilProxy = "127.0.0.1";		// Host su cui fare il bind
	public static boolean isInteractive = true;				// Mi dice se visualizzare o meno la GUI
	public static boolean isServerOn = false;				// Mi dice se evilproxy è eaaviato
	public static final String VERSION = "1.0 beta";		// Identifica la versione di EvilProxy
	public static final String NAME = "Evilproxy";			// Nome del programma
	public static final int X = 710;						// Rappresenta la larghezza della finestra
	public static final int Y = 410;						// Rappresenta la lunghezza della finestra	
	
	//Variabili di configurazione generale
	public static boolean interceptClientRequest = true;
	public static boolean updateClientContentLength = true;
	public static boolean ignoreClientFiletypes = true;
	public static String ignoredClientFiletypes = "ico,gif,jpg,png,css";
	public static boolean logClientRequestToFile = false;
	public static String filenameLogRequests = "./log/evilproxy.log";
	public static boolean interceptServerResponse = false;
	public static boolean updateServerContentLength = true;
	public static boolean ignoreServerNonTextResponse = true;
	public static boolean logServerResponseToFile = false;
	public static boolean doParametersUrlCompliant = true;
	
	// Variabili della configurazione dell'engine
	public static boolean modifyClientRequests = false;			// Mi dice se modificare o meno le richieste del client
	public static ArrayList listaRequests = new ArrayList();	// Contiene i dati di modifica delle richieste
	public static ArrayList listaResponses = new ArrayList();	// Contiene i dati di modifica delle risposte
	public static boolean modifyServerResponses = false;		// Mi dice se modificare o meno le risposte del server
	public static boolean matchingRequestsSensitive = false;	// Mi dice se il matching delle richieste è case sensitive
	public static boolean matchingResponsesSensitive = false;	// Mi dice se il matching delle risposte è case sensitive
	public static boolean matchingRequestsMultiline = true;		// Mi dice se il matching delle richieste è multiline
	public static boolean matchingRequestsAdvanced = false;
	public static boolean matchingRequestsAnchor = true;
	public static boolean matchingResponsesMultiline = true;	// Mi dice se il matching delle risposte è multiline
	public static boolean matchingResponsesAnchor = true;
	public static boolean matchingResponsesAdvanced = false;	
	public static boolean ungunzipResponse = true;				// Mi dice se decompattare le risposte del server
	public static boolean parametersModifyEnabled = false;		// Mi dice se il campo relativo alla modifica dei caparametri dev essere abilitato
	
		
	// Variabili della configurazione del proxy
	private static boolean isSetProxy = false;
	private static int proxyPort = 8081;
	private static String proxyHost = "";	
	
	// Variabili pubbliche
	public static int TIMEOUT = 20000;
	public static int TIMEOUTPROXY = 20000;
	
	
	/**
	 * Costruttore che ha il compito di inizializzare le strutture dati
	 *
	 */
	OptionControl() {		
		initModifyRequests();
		initModifyResponses();
	}
	
	/**
	 * Mi dice se è stato impostato il modo interattivo
	 * @return risultato
	 */
	public static boolean isInteractive() {
		return isInteractive;
	}
	
	/**
	 * Imposta il timeout del proxy
	 *
	 */
	public static void setProxyTimeout(int t) {
		TIMEOUTPROXY = t;
	}
	
	/**
	 * Ritorna il timeout del server
	 * @return
	 */
	public static int getProxyTimeout() {
		return TIMEOUTPROXY;
	}
	
	/**
	 * Inizializza la lista delle modifiche delle richieste
	 *
	 */
	public void initModifyRequests() {		
		listaRequests.add(new ArrayList(Arrays.asList(new Object[] {"","([0-9a-zA-z%-_+]*?)=([0-9a-zA-z%-_+]*?)([&| ])","$1=$2'$3","Blind SQL Injection test"})));
		listaRequests.add(new ArrayList(Arrays.asList(new Object[] {"","([\\?|&])([0-9a-zA-z%-_+]*?)=([0-9a-zA-Z%-_+]*?)$","$1$2=$3'","Blind SQL Injection test"})));
	}
	
	/**
	 * Inizializza la lista delle modifiche delle risposte
	 *
	 */
	public void initModifyResponses() {		
		listaResponses.add(new ArrayList(Arrays.asList(new Object[] {"","<script.*?</script>","<script language=\"Javascript\"></script>","Remove all script code (Matching line breaks must be enabled)"})));		
		}
	
	/**
	 * Mi dice se è impostata la modalità proxy oppure no
	 * @return
	 */
	public static boolean isSetProxy() {
		return isSetProxy;
	}
	
	/**
	 * Imposta la modalità proxy o la disattiva
	 * @param r
	 */
	public static void setProxy(boolean r) {
		isSetProxy = r;
	}
	
	/**
	 * Mi ritorna la porta del proxy da usare
	 * @return
	 */
	public static int getProxyPort() {
		return proxyPort;
	}
	
	/**
	 * Imposta la porta del proxy da usare
	 * @param p
	 */
	public static void setProxyPort(int p) {
		proxyPort = p;
	}
	
	/**
	 * Mi ritorna l'host del proxy a cui connettersi
	 * @return
	 */	
	public static String getProxyHost() {
		return proxyHost;
	}
	
	/**
	 * Imposta l'host del proxy da usare
	 * @param h
	 */
	public static void setProxyHost(String h) {
		proxyHost = h;
	}
	
	/**
	 * Mi dice se le richieste ricevute dal server devono essere modificate tramite il motore di modifica oppure no
	 * @return risultato
	 */
	public boolean isRequestAutomaticModified() {
		return isRequestAutomaticModified;
	}

}
