import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

/**
 * Crea il panello relativo alle opzioni dell'engine panel
 * @author s4tan
 *
 */

public class EPEnginePanel implements ActionListener {
	private JPanel mainPanel; // Contiene la scrollbar la quale contiene tutti i pannelli da visualizzare
	private JPanel enginePanel; // Contiene le aree relative alle opzioni
	private JPanel requestsPanel; // Contiene le opzioni relative alle richieste
	private JPanel responsesPanel; // Contiene le opzioni relative alle risposte
	
	private final int dimPannelloY = 290;
	private final int dimPannelloEstesoY = 390;
	
	// Componenti del pannello delle richieste
	private JCheckBox modRequests;
	private JCheckBox modRequestsAdv;
	private JCheckBox modRequestsSensitive;
	private JCheckBox modRequestsMultiline;
	private JCheckBox modRequestsAnchor;
	private JLabel findLabel;
	private JLabel replaceLabel;
	private JLabel errorRequestsLabel;
	private JLabel infoClientRequestsLabel;
	private JTextField infoClientRequestsString;
	private JTextField findString;
	private JTextField replaceString;
	private JButton addClientRule;	
	private JButton updateRule;
	private JButton upRule;
	private JButton downRule;
	private JButton removeRule;	
	private JTable tableRequests;	
	private String[] columnNamesRequests = {"Enabled","Match","Replace","Info"};
	private JScrollPane scrollPaneRequests;
	private myTableModelEPEnginePanel myModelRequests;
	// Opzioni avanzate	
	private JPanel panelRequestsAdv;
	
	// Componenti del pannello delle risposte
	private JCheckBox modResponses;
	private JCheckBox modResponsesAdv;
	private JCheckBox modResponsesSensitive;	
	private JCheckBox modResponsesMultiline;
	private JCheckBox modResponsesAnchor;
	private JLabel findLabelResponses;
	private JLabel replaceLabelResponses;
	private JLabel errorResponsesLabel;
	private JLabel infoServerResponsesLabel;
	private JTextField infoServerResponsesString;
	private JTextField findStringResponses;
	private JTextField replaceStringResponses;
	private JButton addServerRule;	
	private JButton updateRuleResponses;
	private JButton upRuleResponses;
	private JButton downRuleResponses;
	private JButton removeRuleResponses;	
	private JTable tableResponses;	
	private String[] columnNamesResponses = {"Enabled","Match","Replace","Info"};
	private JScrollPane scrollPaneResponses;
	private myTableModelEPEnginePanelResponses myModelResponses;
	// Opzioni avanzate	
	private JPanel panelResponsesAdv;
	
	private GridBagConstraints layout;
	
	EPEnginePanel() {
		// Inizializzo i pannelli
		mainPanel = new JPanel(new GridBagLayout());
		mainPanel.setBackground(new Color(255,255,255));
		
		enginePanel = new JPanel();
		enginePanel.setBackground(new Color(255,255,255));
		
		requestsPanel = new JPanel(new GridBagLayout());
		requestsPanel.setBackground(new Color(255,255,255));
		requestsPanel.setPreferredSize(new Dimension(550,dimPannelloY));
		
		responsesPanel = new JPanel(new GridBagLayout());
		responsesPanel.setBackground(new Color(255,255,255));
		responsesPanel.setPreferredSize(new Dimension(550,dimPannelloY));
		
		/////////////////////////////////////////////////
		// Creo la struttura del pannello delle richieste		
		TitledBorder bordo = BorderFactory.createTitledBorder( BorderFactory.createLineBorder(new Color(223,217,233)),"Requests Options");			
		requestsPanel.setBorder(bordo);
		modRequests = new JCheckBox("Modify the client requests");		
		modRequests.setBackground(new Color(255,255,255));
		modRequests.setSelected(OptionControl.modifyClientRequests);		
		modRequests.addActionListener(this);
		modRequests.setActionCommand("modRequests");
		modRequests.setToolTipText("Uncheck the button to edit the values");	
		modRequestsAdv = new JCheckBox("Advanced Options");		
		modRequestsAdv.setBackground(new Color(255,255,255));
		modRequestsAdv.setSelected(OptionControl.matchingRequestsSensitive);
		modRequestsAdv.setEnabled(!OptionControl.modifyClientRequests);
		modRequestsAdv.addActionListener(this);
		modRequestsAdv.setActionCommand("modRequestsAdvanced");
		modRequestsAdv.setToolTipText("Click for more options");
		modRequestsAdv.setIcon(new ImageIcon("./img/openaTab.gif"));
		modRequestsAdv.setSelectedIcon(new ImageIcon("./img/closedTab.gif"));		
		panelRequestsAdv = new JPanel(new GridBagLayout());
		panelRequestsAdv.setBackground(new Color(255,255,204));
		panelRequestsAdv.setPreferredSize(new Dimension(550,63));
		bordo = BorderFactory.createTitledBorder( BorderFactory.createLineBorder(new Color(0,0,0)));			
		panelRequestsAdv.setBorder(bordo);
		JLabel advReqOpt = new JLabel("Advanced Requests Options");
		advReqOpt.setPreferredSize(new Dimension(450,20));
		advReqOpt.setMinimumSize(new Dimension(450,20));
		modRequestsSensitive = new JCheckBox("Matching case sensitive ");		
		modRequestsSensitive.setBackground(new Color(255,255,204));
		modRequestsSensitive.setSelected(OptionControl.matchingRequestsSensitive);
		modRequestsSensitive.setEnabled(!OptionControl.modifyClientRequests);
		modRequestsSensitive.addActionListener(this);
		modRequestsSensitive.setActionCommand("modRequestsSensitive");
		modRequestsSensitive.setToolTipText("Matching is case sensitive (there is differce between lowercase and uppercase)");		
		modRequestsMultiline = new JCheckBox("Matching line breaks");		
		modRequestsMultiline.setBackground(new Color(255,255,204));
		modRequestsMultiline.setSelected(OptionControl.matchingRequestsMultiline);
		modRequestsMultiline.setEnabled(!OptionControl.modifyClientRequests);
		modRequestsMultiline.addActionListener(this);
		modRequestsMultiline.setActionCommand("modRequestsMultiline");
		modRequestsMultiline.setToolTipText("Causes the dot to match line breaks");		
		modRequestsAnchor = new JCheckBox("Matching multiline");		
		modRequestsAnchor.setBackground(new Color(255,255,204));
		modRequestsAnchor.setSelected(OptionControl.matchingRequestsAnchor);
		modRequestsAnchor.setEnabled(!OptionControl.modifyClientRequests);
		modRequestsAnchor.addActionListener(this);
		modRequestsAnchor.setActionCommand("modRequestsAnchor");
		modRequestsAnchor.setToolTipText("Causes the start and end of string anchors to match at embedded line breaks");		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;		
		layout.ipady = 2;		
		layout.gridwidth = 3;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		panelRequestsAdv.add(advReqOpt,layout);	
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 1;		
		layout.ipady = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		panelRequestsAdv.add(modRequestsSensitive,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 1;		
		layout.ipady = 2;	
		layout.insets = new Insets(0,25,0,0);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		panelRequestsAdv.add(modRequestsAnchor,layout);			
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 2;		
		layout.ipady = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		panelRequestsAdv.add(modRequestsMultiline,layout);		
		panelRequestsAdv.setVisible(OptionControl.matchingRequestsAdvanced );
		if (panelRequestsAdv.isVisible()) {
			requestsPanel.setPreferredSize(new Dimension(550,dimPannelloEstesoY));
		}
		else {
			requestsPanel.setPreferredSize(new Dimension(550,dimPannelloY));
		}		
		findLabel = new JLabel(" Match ");
		findLabel.setBackground(new Color(255,255,255));
		replaceLabel = new JLabel(" Replace ");
		replaceLabel.setBackground(new Color(255,255,255));		
		findString = new JTextField("",14);		
		findString.setMinimumSize(new Dimension(200,20));		
		findString.setEditable(!OptionControl.modifyClientRequests);			
		replaceString = new JTextField("",14);		
		replaceString.setMinimumSize(new Dimension(200,20));
		replaceString.setEditable(!OptionControl.modifyClientRequests);			
		infoClientRequestsLabel = new JLabel(" Info ");
		infoClientRequestsLabel.setBackground(new Color(255,255,255));
		infoClientRequestsLabel.setMinimumSize(new Dimension(50,20));
		infoClientRequestsString = new JTextField("",14);		
		infoClientRequestsString.setMinimumSize(new Dimension(500,20));		
		infoClientRequestsString.setEditable(!OptionControl.modifyClientRequests);			
		// Creo il bottone di aggiunta regola
		addClientRule = new JButton(new ImageIcon("./img/add.gif"));
		addClientRule.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		addClientRule.setPreferredSize(new Dimension(22,22));
		addClientRule.setMinimumSize(new Dimension(22,22));
		addClientRule.setBackground(new Color(255,255,255));
		addClientRule.setToolTipText("Add the rule to the list");	
		addClientRule.setActionCommand("addRule");
		addClientRule.setEnabled(!OptionControl.modifyClientRequests);
		addClientRule.addActionListener(this);		
		myModelRequests = new myTableModelEPEnginePanel();
		myModelRequests.setDataVector(null,columnNamesRequests);
		initRequestsList(); // Inizializzo la lista delle Requests
		tableRequests = new JTable(myModelRequests);
		tableRequests.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ListSelectionModel rowSM = tableRequests.getSelectionModel();		
		// Gestisco subito la selezione delle righe
		rowSM.addListSelectionListener(new ListSelectionListener() {
		    public void valueChanged(ListSelectionEvent e) {
		        //Ignore extra messages.
		        if (e.getValueIsAdjusting()) return;
		        ListSelectionModel lsm = (ListSelectionModel)e.getSource();
		        if (lsm.isSelectionEmpty()) {
		            return;
		        } else {
		            int row = lsm.getMinSelectionIndex();		            
		            findString.setText((String)myModelRequests.getValueAt(row,1));
			    	replaceString.setText((String)myModelRequests.getValueAt(row,2));
			    	infoClientRequestsString.setText((String)myModelRequests.getValueAt(row,3));			    	
		        }
		    }
		});		
		tableRequests.setBackground(new Color(255,255,255));
		tableRequests.setAutoscrolls(true);
		tableRequests.setEnabled(!OptionControl.modifyClientRequests);			
		tableRequests.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);		   
	    scrollPaneRequests = new JScrollPane(tableRequests);	    
	    scrollPaneRequests.setPreferredSize(new Dimension(470,310));	    
	    // imposto la dimensione delle colonne
		TableColumn column = null;		
		column = tableRequests.getColumnModel().getColumn(0);
		column.setPreferredWidth(50);
		column = tableRequests.getColumnModel().getColumn(1);
		column.setPreferredWidth(130);
		column = tableRequests.getColumnModel().getColumn(2);
		column.setPreferredWidth(130);
		column = tableRequests.getColumnModel().getColumn(3);
		column.setPreferredWidth(187);		
		// Creo il bottone di update della regola
		Icon update = new ImageIcon("./img/forward.gif");
		updateRule = new JButton(new InsetsIcon(update));
		updateRule.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		updateRule.setRolloverEnabled(true);
		updateRule.addActionListener(this);
		updateRule.setEnabled(!OptionControl.modifyClientRequests);
		updateRule.setActionCommand("updateRule");		;
		updateRule.setToolTipText("Update the selected rule and clear the input fields");
		updateRule.setRolloverIcon(new ShadowedIcon(update));
		updateRule.setBorderPainted(false);			
		updateRule.setMinimumSize(new Dimension(32,30));
		updateRule.setBackground(new Color(255,255,255));		
		updateRule.setDisabledIcon(new ImageIcon("./img/forwardDisabled.gif"));		
		// Creo il bottone di rimozione della regola
		Icon remove = new ImageIcon("./img/drop.gif");
		removeRule = new JButton(new InsetsIcon(remove));
		removeRule.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		removeRule.setRolloverEnabled(true);
		removeRule.addActionListener(this);
		removeRule.setEnabled(!OptionControl.modifyClientRequests);
		removeRule.setActionCommand("removeRule");		;
		removeRule.setToolTipText("Remove the selected rule");
		removeRule.setRolloverIcon(new ShadowedIcon(remove));
		removeRule.setBorderPainted(false);			
		removeRule.setMinimumSize(new Dimension(32,30));
		removeRule.setBackground(new Color(255,255,255));		
		removeRule.setDisabledIcon(new ImageIcon("./img/dropDisabled.gif"));		
		// Creo il bottone di up della regola
		Icon up = new ImageIcon("./img/up.gif");
		upRule = new JButton(new InsetsIcon(up));
		upRule.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		upRule.setRolloverEnabled(true);
		upRule.addActionListener(this);
		upRule.setEnabled(!OptionControl.modifyClientRequests);
		upRule.setActionCommand("upRule");		;
		upRule.setToolTipText("Move the selected up");
		upRule.setRolloverIcon(new ShadowedIcon(up));
		upRule.setBorderPainted(false);			
		upRule.setMinimumSize(new Dimension(32,31));
		upRule.setBackground(new Color(255,255,255));		
		upRule.setDisabledIcon(new ImageIcon("./img/upDisabled.gif"));		
		// Creo il bottone di down della regola
		Icon down = new ImageIcon("./img/down.gif");
		downRule = new JButton(new InsetsIcon(down));
		downRule.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		downRule.setRolloverEnabled(true);
		downRule.addActionListener(this);
		downRule.setEnabled(!OptionControl.modifyClientRequests);
		downRule.setActionCommand("downRule");		;
		downRule.setToolTipText("Move the selected down");
		downRule.setRolloverIcon(new ShadowedIcon(down));
		downRule.setBorderPainted(false);			
		downRule.setMinimumSize(new Dimension(32,31));
		downRule.setBackground(new Color(255,255,255));		
		downRule.setDisabledIcon(new ImageIcon("./img/downDisabled.gif"));
		errorRequestsLabel = new JLabel(" ");
		errorRequestsLabel.setForeground(new Color(255,0,0));
		errorRequestsLabel.setBackground(new Color(255,255,255));	
		
		// Aggiungo i componenti al pannello delle richieste
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;
		layout.gridwidth = 2;
		layout.ipady = 1;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(modRequests,layout);			
		layout = new GridBagConstraints();
		layout.gridx = 2;
		layout.gridy = 0;
		layout.gridwidth = 2;
		layout.ipady = 1;		
		layout.insets = new Insets(0,0,4,0);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(modRequestsAdv,layout);	
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 1;
		layout.gridwidth = 6;
		layout.ipady = 1;
		layout.insets = new Insets(0,5,13,0);
		layout.weightx = 1.0;
		layout.fill = GridBagConstraints.HORIZONTAL;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(panelRequestsAdv,layout);			
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(findLabel,layout);
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(findString,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 2;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(replaceLabel,layout);
		layout = new GridBagConstraints();
		layout.gridx = 3;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(replaceString,layout);	
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 3;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(infoClientRequestsLabel,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridwidth = 5;
		layout.gridy = 3;		
		layout.insets = new Insets(0,0,10,0);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(infoClientRequestsString,layout);		
		layout = new GridBagConstraints();		
		layout.gridx = 6;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.CENTER;		
		requestsPanel.add(addClientRule,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 4;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;	
		layout.gridwidth = 6;
		layout.gridheight = 4;
		layout.weighty = 1.0;
		layout.weightx = 1.0;		
		layout.insets = new Insets(0,5,0,0);
		layout.fill = GridBagConstraints.BOTH;
		requestsPanel.add(scrollPaneRequests,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 6;
		layout.gridy = 4;	
		layout.insets = new Insets(0,10,10,5);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(updateRule,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 6;
		layout.gridy = 5;		
		layout.insets = new Insets(0,10,10,5);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(removeRule,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 6;
		layout.gridy = 6;		
		layout.insets = new Insets(0,10,10,5);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(upRule,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 6;
		layout.gridy = 7;		
		layout.insets = new Insets(0,10,10,5);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(downRule,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 8;	
		layout.gridwidth = 7;
		layout.insets = new Insets(0,5,0,0);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		requestsPanel.add(errorRequestsLabel,layout);	
				
			
		/////////////////////////////////////////////////
		// Creo la struttura del pannello delle richieste		
		bordo = BorderFactory.createTitledBorder( BorderFactory.createLineBorder(new Color(223,217,233)),"Responses Options");			
		responsesPanel.setBorder(bordo);		
		modResponses = new JCheckBox("Modify the server responses");		
		modResponses.setBackground(new Color(255,255,255));
		modResponses.setSelected(OptionControl.modifyServerResponses);		
		modResponses.addActionListener(this);
		modResponses.setActionCommand("modResponses");
		modResponses.setToolTipText("Uncheck the button to edit the values");			
		modResponsesAdv = new JCheckBox("Advanced Options");		
		modResponsesAdv.setBackground(new Color(255,255,255));
		modResponsesAdv.setSelected(OptionControl.matchingResponsesSensitive);
		modResponsesAdv.setEnabled(!OptionControl.modifyServerResponses);
		modResponsesAdv.addActionListener(this);
		modResponsesAdv.setActionCommand("modResponsesAdvanced");
		modResponsesAdv.setToolTipText("Click for more options");
		modResponsesAdv.setIcon(new ImageIcon("./img/openaTab.gif"));
		modResponsesAdv.setSelectedIcon(new ImageIcon("./img/closedTab.gif"));	
		panelResponsesAdv = new JPanel(new GridBagLayout());
		panelResponsesAdv.setBackground(new Color(255,255,204));
		panelResponsesAdv.setPreferredSize(new Dimension(550,63));
		bordo = BorderFactory.createTitledBorder( BorderFactory.createLineBorder(new Color(0,0,0)));			
		panelResponsesAdv.setBorder(bordo);
		JLabel advResOpt = new JLabel("Advanced Responses Options");
		advResOpt.setPreferredSize(new Dimension(450,20));
		advResOpt.setMinimumSize(new Dimension(450,20));
		modResponsesSensitive = new JCheckBox("Matching case sensitive ");		
		modResponsesSensitive.setSelected(OptionControl.matchingResponsesSensitive);
		modResponsesSensitive.setEnabled(!OptionControl.modifyServerResponses);
		modResponsesSensitive.addActionListener(this);
		modResponsesSensitive.setBackground(new Color(255,255,204));
		modResponsesSensitive.setActionCommand("modResponsesSensitive");
		modResponsesSensitive.setToolTipText("Matching is case sensitive (there is differce between lowercase and uppercase)");
		modResponsesMultiline = new JCheckBox("Matching line breaks");		
		modResponsesMultiline.setBackground(new Color(255,255,204));
		modResponsesMultiline.setSelected(OptionControl.matchingResponsesMultiline);
		modResponsesMultiline.setEnabled(!OptionControl.modifyClientRequests);
		modResponsesMultiline.addActionListener(this);
		modResponsesMultiline.setActionCommand("modResponsesMultiline");
		modResponsesMultiline.setToolTipText("Causes the dot to match line breaks");		
		modResponsesAnchor = new JCheckBox("Matching multiline");		
		modResponsesAnchor.setBackground(new Color(255,255,204));
		modResponsesAnchor.setSelected(OptionControl.matchingResponsesAnchor);
		modResponsesAnchor.setEnabled(!OptionControl.modifyServerResponses);
		modResponsesAnchor.addActionListener(this);
		modResponsesAnchor.setActionCommand("modRequestsAnchor");
		modResponsesAnchor.setToolTipText("Causes the start and end of string anchors to match at embedded line breaks");		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;		
		layout.ipady = 2;	
		layout.gridwidth = 3;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		panelResponsesAdv.add(advResOpt,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 1;		
		layout.ipady = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		panelResponsesAdv.add(modResponsesSensitive,layout);
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 1;		
		layout.ipady = 2;	
		layout.insets = new Insets(0,25,0,0);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		panelResponsesAdv.add(modResponsesAnchor,layout);			
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 2;		
		layout.ipady = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		panelResponsesAdv.add(modResponsesMultiline,layout);		
		panelResponsesAdv.setVisible(OptionControl.matchingResponsesAdvanced );
		if (panelResponsesAdv.isVisible()) {
			responsesPanel.setPreferredSize(new Dimension(550,dimPannelloEstesoY));
		}
		else {
			responsesPanel.setPreferredSize(new Dimension(550,dimPannelloY));
		}		
		findLabelResponses = new JLabel(" Match ");
		findLabelResponses.setBackground(new Color(255,255,255));
		replaceLabelResponses = new JLabel(" Replace ");
		replaceLabelResponses.setBackground(new Color(255,255,255));		
		findStringResponses = new JTextField("",14);		
		findStringResponses.setMinimumSize(new Dimension(200,20));		
		findStringResponses.setEditable(!OptionControl.modifyServerResponses);			
		replaceStringResponses = new JTextField("",14);	
		replaceStringResponses.setMinimumSize(new Dimension(200,20));
		replaceStringResponses.setEditable(!OptionControl.modifyServerResponses);			
		infoServerResponsesLabel = new JLabel(" Info ");
		infoServerResponsesLabel.setBackground(new Color(255,255,255));
		infoServerResponsesLabel.setMinimumSize(new Dimension(50,20));
		infoServerResponsesString = new JTextField("",14);		
		infoServerResponsesString.setMinimumSize(new Dimension(500,20));		
		infoServerResponsesString.setEditable(!OptionControl.modifyServerResponses);			
		// Creo il bottone di aggiunta regola
		addServerRule = new JButton(new ImageIcon("./img/add.gif"));
		addServerRule.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		addServerRule.setPreferredSize(new Dimension(22,22));
		addServerRule.setMinimumSize(new Dimension(22,22));
		addServerRule.setBackground(new Color(255,255,255));
		addServerRule.setToolTipText("Add the rule to the list");	
		addServerRule.setActionCommand("addRuleResponses");
		addServerRule.setEnabled(!OptionControl.modifyServerResponses);
		addServerRule.addActionListener(this);		
		myModelResponses = new myTableModelEPEnginePanelResponses();
		myModelResponses.setDataVector(null,columnNamesResponses);
		initResponsesList(); // Inizializzo la lista delle Requests
		tableResponses = new JTable(myModelResponses);
		tableResponses.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ListSelectionModel rowSMResponses = tableResponses.getSelectionModel();		
		// Gestisco subito la selezione delle righe
		rowSMResponses.addListSelectionListener(new ListSelectionListener() {
		    public void valueChanged(ListSelectionEvent e) {
		        //Ignore extra messages.
		        if (e.getValueIsAdjusting()) return;
		        ListSelectionModel lsm = (ListSelectionModel)e.getSource();
		        if (lsm.isSelectionEmpty()) {
		            return;
		        } else {
		            int row = lsm.getMinSelectionIndex();		            
		            findStringResponses.setText((String)myModelResponses.getValueAt(row,1));
			    	replaceStringResponses.setText((String)myModelResponses.getValueAt(row,2));
			    	infoServerResponsesString.setText((String)myModelResponses.getValueAt(row,3));			    	
		        }
		    }
		});		
		tableResponses.setBackground(new Color(255,255,255));
		tableResponses.setAutoscrolls(true);
		tableResponses.setEnabled(!OptionControl.modifyServerResponses);			
		tableResponses.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);		   
	    scrollPaneResponses = new JScrollPane(tableResponses);	    
	    scrollPaneResponses.setPreferredSize(new Dimension(470,310));	    
	    // imposto la dimensione delle colonne
		column = null;		
		column = tableResponses.getColumnModel().getColumn(0);
		column.setPreferredWidth(50);
		column = tableResponses.getColumnModel().getColumn(1);
		column.setPreferredWidth(130);
		column = tableResponses.getColumnModel().getColumn(2);
		column.setPreferredWidth(130);
		column = tableResponses.getColumnModel().getColumn(3);
		column.setPreferredWidth(187);		
		// Creo il bottone di update della regola
		Icon updateResponses = new ImageIcon("./img/forward.gif");
		updateRuleResponses = new JButton(new InsetsIcon(updateResponses));
		updateRuleResponses.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		updateRuleResponses.setRolloverEnabled(true);
		updateRuleResponses.addActionListener(this);
		updateRuleResponses.setEnabled(!OptionControl.modifyServerResponses);
		updateRuleResponses.setActionCommand("updateRuleResponses");		;
		updateRuleResponses.setToolTipText("Update the selected rule and clear the input fields");
		updateRuleResponses.setRolloverIcon(new ShadowedIcon(updateResponses));
		updateRuleResponses.setBorderPainted(false);			
		updateRuleResponses.setMinimumSize(new Dimension(32,30));
		updateRuleResponses.setBackground(new Color(255,255,255));		
		updateRuleResponses.setDisabledIcon(new ImageIcon("./img/forwardDisabled.gif"));		
		// Creo il bottone di rimozione della regola
		Icon removeResponses = new ImageIcon("./img/drop.gif");
		removeRuleResponses = new JButton(new InsetsIcon(removeResponses));
		removeRuleResponses.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		removeRuleResponses.setRolloverEnabled(true);
		removeRuleResponses.addActionListener(this);
		removeRuleResponses.setEnabled(!OptionControl.modifyServerResponses);
		removeRuleResponses.setActionCommand("removeRuleResponses");		;
		removeRuleResponses.setToolTipText("Remove the selected rule");
		removeRuleResponses.setRolloverIcon(new ShadowedIcon(removeResponses));
		removeRuleResponses.setBorderPainted(false);			
		removeRuleResponses.setMinimumSize(new Dimension(32,30));
		removeRuleResponses.setBackground(new Color(255,255,255));		
		removeRuleResponses.setDisabledIcon(new ImageIcon("./img/dropDisabled.gif"));		
		// Creo il bottone di up della regola
		Icon upResponses = new ImageIcon("./img/up.gif");
		upRuleResponses = new JButton(new InsetsIcon(upResponses));
		upRuleResponses.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		upRuleResponses.setRolloverEnabled(true);
		upRuleResponses.addActionListener(this);
		upRuleResponses.setEnabled(!OptionControl.modifyServerResponses);
		upRuleResponses.setActionCommand("upRuleResponses");		;
		upRuleResponses.setToolTipText("Move the selected up");
		upRuleResponses.setRolloverIcon(new ShadowedIcon(upResponses));
		upRuleResponses.setBorderPainted(false);			
		upRuleResponses.setMinimumSize(new Dimension(32,31));
		upRuleResponses.setBackground(new Color(255,255,255));		
		upRuleResponses.setDisabledIcon(new ImageIcon("./img/upDisabled.gif"));		
		// Creo il bottone di down della regola
		Icon downResponses = new ImageIcon("./img/down.gif");
		downRuleResponses = new JButton(new InsetsIcon(downResponses));
		downRuleResponses.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		downRuleResponses.setRolloverEnabled(true);
		downRuleResponses.addActionListener(this);
		downRuleResponses.setEnabled(!OptionControl.modifyServerResponses);
		downRuleResponses.setActionCommand("downRuleResponses");		;
		downRuleResponses.setToolTipText("Move the selected down");
		downRuleResponses.setRolloverIcon(new ShadowedIcon(downResponses));
		downRuleResponses.setBorderPainted(false);			
		downRuleResponses.setMinimumSize(new Dimension(32,31));
		downRuleResponses.setBackground(new Color(255,255,255));		
		downRuleResponses.setDisabledIcon(new ImageIcon("./img/downDisabled.gif"));
		errorResponsesLabel = new JLabel(" ");
		errorResponsesLabel.setForeground(new Color(255,0,0));
		errorResponsesLabel.setBackground(new Color(255,255,255));	
		
		// Aggiungo i componenti al pannello delle risposte		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;
		layout.gridwidth = 2;
		layout.ipady = 1;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(modResponses,layout);			
		layout = new GridBagConstraints();
		layout.gridx = 2;
		layout.gridy = 0;
		layout.gridwidth = 2;
		layout.ipady = 1;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(modResponsesAdv,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 1;
		layout.gridwidth = 6;
		layout.ipady = 1;
		layout.insets = new Insets(0,5,13,0);
		layout.weightx = 1.0;
		layout.fill = GridBagConstraints.HORIZONTAL;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(panelResponsesAdv,layout);	
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(findLabelResponses,layout);
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(findStringResponses,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 2;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(replaceLabelResponses,layout);
		layout = new GridBagConstraints();
		layout.gridx = 3;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(replaceStringResponses,layout);	
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 3;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(infoServerResponsesLabel,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 3;
		layout.gridwidth = 5;
		layout.insets = new Insets(0,0,10,0);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(infoServerResponsesString,layout);		
		layout = new GridBagConstraints();		
		layout.gridx = 6;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.CENTER;		
		responsesPanel.add(addServerRule,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 4;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;	
		layout.gridwidth = 6;
		layout.gridheight = 4;
		layout.weighty = 1.0;
		layout.weightx = 1.0;		
		layout.insets = new Insets(0,5,0,0);
		layout.fill = GridBagConstraints.BOTH;
		responsesPanel.add(scrollPaneResponses,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 6;
		layout.gridy = 4;	
		layout.insets = new Insets(0,10,10,5);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(updateRuleResponses,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 6;
		layout.gridy = 5;		
		layout.insets = new Insets(0,10,10,5);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(removeRuleResponses,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 6;
		layout.gridy = 6;		
		layout.insets = new Insets(0,10,10,5);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(upRuleResponses,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 6;
		layout.gridy = 7;		
		layout.insets = new Insets(0,10,10,5);
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(downRuleResponses,layout);		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 8;	
		layout.insets = new Insets(0,5,0,0);
		layout.gridwidth = 7;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;			
		responsesPanel.add(errorResponsesLabel,layout);		
		
		// Aggiungo i pannelli all'enginePanel
		enginePanel.add(requestsPanel);				
		enginePanel.add(responsesPanel);
	}
	
	public void actionPerformed(ActionEvent e) {	
		if (e.getSource() instanceof JButton) { // Gestione dei pulsanti di aggiornamento
			if (e.getActionCommand() == "addRule") {
				if (findString.getText().equals("")) {
					errorRequestsLabel.setText("You must specified the string to match");
					return;
				}
				// Controllo se la regex è valida
				try {								
					Pattern.compile(findString.getText());					
				}
				catch(PatternSyntaxException ignored){
					errorRequestsLabel.setText("Invalid Regular Expression");
					return;
				}
								
				myModelRequests.addRow(new Object[]{new Boolean(true),
										new String(findString.getText()),
										new String(replaceString.getText()),
										new String(infoClientRequestsString.getText())});
				findString.setText("");
				replaceString.setText("");
				infoClientRequestsString.setText("");				
				errorRequestsLabel.setText(" ");
				myModelRequests.setSelectedRow(-1);
			}			
			else if (e.getActionCommand() == "upRule") {
				if (myModelRequests.getLastSelectedRow() > 0) {
					myModelRequests.moveRow(myModelRequests.getLastSelectedRow(),myModelRequests.getLastSelectedRow(),myModelRequests.getLastSelectedRow()-1);
					myModelRequests.setSelectedRow(myModelRequests.getLastSelectedRow()-1);					
				}
			}			
			else if (e.getActionCommand() == "downRule") {				
				if (myModelRequests.getLastSelectedRow() >= 0 && myModelRequests.getLastSelectedRow() < myModelRequests.getRowCount()-1) {
					myModelRequests.moveRow(myModelRequests.getLastSelectedRow(),myModelRequests.getLastSelectedRow(),myModelRequests.getLastSelectedRow()+1);
					myModelRequests.setSelectedRow(myModelRequests.getLastSelectedRow()+1);				
				}
			}	
			else if (e.getActionCommand() == "removeRule") {			
				if (myModelRequests.getLastSelectedRow() >= 0) {
					myModelRequests.removeRow(myModelRequests.getLastSelectedRow());
					findString.setText("");
					replaceString.setText("");
					infoClientRequestsString.setText("");
					errorRequestsLabel.setText(" ");
				}
			}	
			else if (e.getActionCommand() == "updateRule") {			
				if (myModelRequests.getLastSelectedRow() >= 0) {
					// Controllo la validità
					if (findString.getText().equals("")) {
						errorRequestsLabel.setText("You must specified the string to match");
						return;
					}
					// Controllo se la regex è valida
					try {								
						Pattern.compile(findString.getText());						
					}
					catch(PatternSyntaxException ignored){
						errorRequestsLabel.setText("Invalid Regular Expression");
						return;
					}											
					
					errorRequestsLabel.setText("");					
					myModelRequests.setValueAt(findString.getText(),myModelRequests.getLastSelectedRow(),1);
					myModelRequests.setValueAt(replaceString.getText(),myModelRequests.getLastSelectedRow(),2);
					myModelRequests.setValueAt(infoClientRequestsString.getText(),myModelRequests.getLastSelectedRow(),3);
					findString.setText("");
					replaceString.setText("");
					infoClientRequestsString.setText("");
					errorRequestsLabel.setText(" ");
					myModelRequests.setSelectedRow(-1);
				}
			}				
			else if (e.getActionCommand() == "addRuleResponses") {
				// Controllo la validità
				if (findStringResponses.getText().equals("")) {
					errorResponsesLabel.setText("You must specified the string to match");
					return;
				}
				// Controllo se la regex è valida
				try {								
					Pattern.compile(findStringResponses.getText());					
				}
				catch(PatternSyntaxException ignored){
					errorResponsesLabel.setText("Invalid Regular Expression");
					return;
				}
								
				myModelResponses.addRow(new Object[]{new Boolean(true),
										new String(findStringResponses.getText()),
										new String(replaceStringResponses.getText()),
										new String(infoServerResponsesString.getText())});
				findStringResponses.setText("");
				replaceStringResponses.setText("");
				infoServerResponsesString.setText("");				
				errorResponsesLabel.setText(" ");
				myModelResponses.setSelectedRow(-1);
			}			
			else if (e.getActionCommand() == "upRuleResponses") {
				if (myModelResponses.getLastSelectedRow() > 0) {
					myModelResponses.moveRow(myModelResponses.getLastSelectedRow(),myModelResponses.getLastSelectedRow(),myModelResponses.getLastSelectedRow()-1);
					myModelResponses.setSelectedRow(myModelResponses.getLastSelectedRow()-1);					
				}
			}			
			else if (e.getActionCommand() == "downRuleResponses") {				
				if (myModelResponses.getLastSelectedRow() >= 0 && myModelResponses.getLastSelectedRow() < myModelResponses.getRowCount()-1) {
					myModelResponses.moveRow(myModelResponses.getLastSelectedRow(),myModelResponses.getLastSelectedRow(),myModelResponses.getLastSelectedRow()+1);
					myModelResponses.setSelectedRow(myModelResponses.getLastSelectedRow()+1);				
				}
			}	
			else if (e.getActionCommand() == "removeRuleResponses") {			
				if (myModelResponses.getLastSelectedRow() >= 0) {
					myModelResponses.removeRow(myModelResponses.getLastSelectedRow());
					findStringResponses.setText("");
					replaceStringResponses.setText("");
					infoServerResponsesString.setText("");	
					errorResponsesLabel.setText(" ");
				}
			}	
			else if (e.getActionCommand() == "updateRuleResponses") {			
				if (myModelResponses.getLastSelectedRow() >= 0) {
					// Controllo la validità
					if (findStringResponses.getText().equals("")) {
						errorResponsesLabel.setText("You must specified the string to match");
						return;
					}
					// Controllo se la regex è valida
					try {								
						Pattern.compile(findStringResponses.getText());											
					}
					catch(PatternSyntaxException ignored){
						errorResponsesLabel.setText("Invalid Regular Expression");
						return;
					}					
					errorResponsesLabel.setText("");					
					myModelResponses.setValueAt(findStringResponses.getText(),myModelResponses.getLastSelectedRow(),1);
					myModelResponses.setValueAt(replaceStringResponses.getText(),myModelResponses.getLastSelectedRow(),2);
					myModelResponses.setValueAt(infoServerResponsesString.getText(),myModelResponses.getLastSelectedRow(),3);
					findStringResponses.setText("");
					replaceStringResponses.setText("");
					infoServerResponsesString.setText("");
					errorResponsesLabel.setText(" ");
					myModelResponses.setSelectedRow(-1);
				}
			}	
		}
		else if (e.getSource() instanceof JCheckBox) { // Gestione delle opzioni generali
			if (e.getActionCommand() == "modRequests") {
				OptionControl.modifyClientRequests = modRequests.isSelected();
				replaceString.setEditable(!OptionControl.modifyClientRequests);
				findString.setEditable(!OptionControl.modifyClientRequests);	
				addClientRule.setEnabled(!OptionControl.modifyClientRequests);
				tableRequests.setEnabled(!OptionControl.modifyClientRequests);
				updateRule.setEnabled(!OptionControl.modifyClientRequests);
				removeRule.setEnabled(!OptionControl.modifyClientRequests);
				upRule.setEnabled(!OptionControl.modifyClientRequests);
				downRule.setEnabled(!OptionControl.modifyClientRequests);
				modRequestsMultiline.setEnabled(!OptionControl.modifyClientRequests);
				modRequestsAnchor.setEnabled(!OptionControl.modifyClientRequests);
				infoClientRequestsString.setEditable(!OptionControl.modifyClientRequests);
				modRequestsSensitive.setEnabled(!OptionControl.modifyClientRequests);
				myModelRequests.setSelectedRow(-1); // Deseleziono tutte le varie righe
				updateRequestsList(); // Aggiorno la lista
				
				findString.setText("");
				replaceString.setText("");
				infoClientRequestsString.setText("");
			}
			else if (e.getActionCommand() == "modRequestsAdvanced") {
				OptionControl.matchingRequestsAdvanced = modRequestsAdv.isSelected();				
				panelRequestsAdv.setVisible(OptionControl.matchingRequestsAdvanced );				
				if (panelRequestsAdv.isVisible()) {
					requestsPanel.setPreferredSize(new Dimension(550,dimPannelloEstesoY));
				}
				else {
					requestsPanel.setPreferredSize(new Dimension(550,dimPannelloY));
				}
				
			}
			else if (e.getActionCommand() == "modRequestsAnchor") {
				OptionControl.matchingRequestsAnchor = modRequestsAnchor.isSelected();
			}
			else if (e.getActionCommand() == "modRequestsSensitive") {
				OptionControl.matchingRequestsSensitive = modRequestsSensitive.isSelected();								
			}
			else if (e.getActionCommand() == "modRequestsMultiline") {
				OptionControl.matchingRequestsMultiline = modRequestsMultiline.isSelected();
			}
			else if (e.getActionCommand() == "modResponses") {
				OptionControl.modifyServerResponses = modResponses.isSelected();
				replaceStringResponses.setEditable(!OptionControl.modifyServerResponses);
				findStringResponses.setEditable(!OptionControl.modifyServerResponses);	
				addServerRule.setEnabled(!OptionControl.modifyServerResponses);
				tableResponses.setEnabled(!OptionControl.modifyServerResponses);
				updateRuleResponses.setEnabled(!OptionControl.modifyServerResponses);
				removeRuleResponses.setEnabled(!OptionControl.modifyServerResponses);
				upRuleResponses.setEnabled(!OptionControl.modifyServerResponses);
				modResponsesAnchor.setEnabled(!OptionControl.modifyServerResponses);
				downRuleResponses.setEnabled(!OptionControl.modifyServerResponses);
				infoServerResponsesString.setEditable(!OptionControl.modifyServerResponses);
				modResponsesSensitive.setEnabled(!OptionControl.modifyServerResponses);
				modResponsesMultiline.setEnabled(!OptionControl.modifyServerResponses);
				myModelResponses.setSelectedRow(-1); // Deseleziono tutte le varie righe
				updateResponsesList(); // Aggiorno la lista
				
				findStringResponses.setText("");
				replaceStringResponses.setText("");
				infoServerResponsesString.setText("");	
			}
			else if (e.getActionCommand() == "modResponsesAdvanced") {
				OptionControl.matchingResponsesAdvanced = modResponsesAdv.isSelected();				
				panelResponsesAdv.setVisible(OptionControl.matchingResponsesAdvanced );				
				if (panelResponsesAdv.isVisible()) {
					responsesPanel.setPreferredSize(new Dimension(550,dimPannelloEstesoY));
				}
				else {
					responsesPanel.setPreferredSize(new Dimension(550,dimPannelloY));
				}
				
			}
			else if (e.getActionCommand() == "modResponsesAnchor") {
				OptionControl.matchingResponsesAnchor = modResponsesAnchor.isSelected();
			}
			else if (e.getActionCommand() == "modResponsesSensitive") {
				OptionControl.matchingResponsesSensitive = modResponsesSensitive.isSelected();
			}
			else if (e.getActionCommand() == "modResponsesMultiline") {
				OptionControl.matchingResponsesMultiline = modResponsesMultiline.isSelected();				
			}
		}		
	}
	
	public JPanel getPanel() {
		// Aggiungo l'immagine
		GridBagConstraints layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;	
		layout.weightx = 1.0;		
		layout.fill = GridBagConstraints.HORIZONTAL;	
		mainPanel.add(new JLabel(new ImageIcon("./img/EPEngineBar.gif")),layout);
		
		// Aggiungo il pannello delle requests
		JPanel scrolledPanel = new JPanel(new GridBagLayout());
				
		layout.gridx = 0;
		layout.gridy = 1;	
		layout.weighty = 1.0;
		layout.weightx = 1.0;		
		layout.fill = GridBagConstraints.BOTH;	
		scrolledPanel.add(requestsPanel,layout);
				
		// Aggiungo il pannello delle responses
		layout.gridx = 0;
		layout.gridy = 2;	
		layout.weighty = 1.0;
		layout.weightx = 1.0;		
		layout.fill = GridBagConstraints.BOTH;		
		scrolledPanel.add(responsesPanel,layout);		
				
		// Creo la JScrollPane e la aggiungo al pannello principale
		JScrollPane scrollArea = new JScrollPane(scrolledPanel);
		scrollArea.setAutoscrolls(true);
		scrollArea.setPreferredSize(new Dimension(570,310));
		scrollArea.setBorder(null);
		mainPanel.add(scrollArea,layout);
		return mainPanel;
	}
	
	
	private class myTableModelEPEnginePanel extends DefaultTableModel {
			
		public boolean isCellEditable(int row, int col) {			
			if (col == 0) {
				return true;
			}
	        return false;
	    }   	
	  
	    public Class getColumnClass(int c) {
	        return getValueAt(0, c).getClass();    	
	    }   
	    
	    public int getLastSelectedRow() {
	    	ListSelectionModel rowSM = tableRequests.getSelectionModel();
	    	return rowSM.getMinSelectionIndex();	    	
	    }	
	    
	    public void setSelectedRow(int v) {
	    	ListSelectionModel rowSM = tableRequests.getSelectionModel();
	    	if (v >= 0) {
	    		rowSM.setLeadSelectionIndex(v);
	    	}
	    	else {
	    		rowSM.removeSelectionInterval(0,myModelRequests.getRowCount()-1);
	    	}
	    	
	    }
	   
	}
	
	private class myTableModelEPEnginePanelResponses extends DefaultTableModel {
		
		public boolean isCellEditable(int row, int col) {			
			if (col == 0) {
				return true;
			}
	        return false;
	    }   	
	  
	    public Class getColumnClass(int c) {
	        return getValueAt(0, c).getClass();    	
	    }   
	    
	    public int getLastSelectedRow() {
	    	ListSelectionModel rowSM = tableResponses.getSelectionModel();
	    	return rowSM.getMinSelectionIndex();	    	
	    }	
	    
	    public void setSelectedRow(int v) {
	    	ListSelectionModel rowSM = tableResponses.getSelectionModel();
	    	if (v >= 0) {
	    		rowSM.setLeadSelectionIndex(v);
	    	}
	    	else {
	    		rowSM.removeSelectionInterval(0,myModelResponses.getRowCount()-1);
	    	}
	    	
	    }
	   
	}
	
	private void initRequestsList() {
		ArrayList tmp;	
		for(int i=0;i<OptionControl.listaRequests.size();i++) {
			tmp = new ArrayList((ArrayList)OptionControl.listaRequests.get(i)); // Recupero l'elemento			
			myModelRequests.addRow(new Object[]{new Boolean(true),tmp.get(1),tmp.get(2),tmp.get(3)});
		}
	}
	
	private void initResponsesList() {
		ArrayList tmp;		
		for(int i=0;i<OptionControl.listaResponses.size();i++) {
			tmp = new ArrayList((ArrayList)OptionControl.listaResponses.get(i)); // Recupero l'elemento			
			myModelResponses.addRow(new Object[]{new Boolean(true),tmp.get(1),tmp.get(2),tmp.get(3)});
		}
	}
	
	private void updateRequestsList() {
		ArrayList tmp;		
		OptionControl.listaRequests = new ArrayList();
		for(int i=0;i<myModelRequests.getRowCount();i++) {
			tmp = new ArrayList();			
			tmp.add(0,myModelRequests.getValueAt(i,0));
			tmp.add(1,myModelRequests.getValueAt(i,1));
			tmp.add(2,myModelRequests.getValueAt(i,2));
			tmp.add(3,myModelRequests.getValueAt(i,3));
			OptionControl.listaRequests.add(tmp);
		}
	}
	
	private void updateResponsesList() {
		ArrayList tmp;		
		OptionControl.listaResponses = new ArrayList();
		for(int i=0;i<myModelResponses.getRowCount();i++) {
			tmp = new ArrayList();			
			tmp.add(0,myModelResponses.getValueAt(i,0));
			tmp.add(1,myModelResponses.getValueAt(i,1));
			tmp.add(2,myModelResponses.getValueAt(i,2));
			tmp.add(3,myModelResponses.getValueAt(i,3));
			OptionControl.listaResponses.add(tmp);
		}
	}
}


