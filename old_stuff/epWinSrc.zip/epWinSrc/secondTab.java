import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.regex.Pattern;
import java.net.Socket;
import java.io.IOException;
import javax.swing.*;
import javax.swing.border.*;

/**
 * Crea il secondo tab.
 * @author s4tan
 *
 */
public class secondTab implements ActionListener, ItemListener  {
	private JPanel panel;
	private JPanel menuPanel;
	private JPanel contentPanel;
	private JPanel generalPanel;
	private JPanel proxyPanel;
	private JPanel enginePanel;
	private JButton generalB;
	private JButton proxyB;
	private JButton engineB;
	private GridBagConstraints c;	
	private JTextField server = null;
	private JTextField port = null;
	private JTextField proxyTimeout = null;
	private JCheckBox box;
	private JLabel proxyError;
	private JScrollPane scrollBarr0;
	private JScrollPane scrollBarr1;
	private JScrollPane scrollBarr2;	
	
	// Definizione delle icone dei pulsanti delle opzioni
	// Icone pulsante general
	private Icon generalA = new ImageIcon("./img/generalA.gif");
	private Icon generalS = new ImageIcon("./img/generalS.gif");
	private Icon generalN = new ImageIcon("./img/generalN.gif");
	private Icon generalP = new ImageIcon("./img/generalP.gif");
	// Icone pulsante proxy
	private Icon proxyA = new ImageIcon("./img/proxyA.gif");
	private Icon proxyS = new ImageIcon("./img/proxyS.gif");
	private Icon proxyN = new ImageIcon("./img/proxyN.gif");
	private Icon proxyP = new ImageIcon("./img/proxyP.gif");
	// Icone pulsante E.P. Engine
	private Icon engineA = new ImageIcon("./img/engineA.gif");
	private Icon engineS = new ImageIcon("./img/engineS.gif");
	private Icon engineN = new ImageIcon("./img/engineN.gif");
	private Icon engineP = new ImageIcon("./img/engineP.gif");
	
	secondTab() {
		panel = new JPanel(new GridBagLayout());
		panel.setBackground(new Color(255,255,255));
		menuPanel = new JPanel(new GridLayout(4,1));		
		TitledBorder bordo =BorderFactory.createTitledBorder( BorderFactory.createLineBorder(Color.DARK_GRAY));
		
		menuPanel.setBorder(bordo);
		menuPanel.setBackground(new Color(255,255,255));
		contentPanel = new JPanel(new GridBagLayout());
		contentPanel.setBackground(new Color(255,255,255));
		
		JPanel generalP = new JPanel();
		generalP.setBackground(new Color(255,255,255));
		generalB = new JButton(generalA);
		generalB.setRolloverEnabled(false);		
		generalB.setRolloverIcon(null);	
		generalB.setBorderPainted(false);				
		generalB.setPreferredSize(new Dimension(90,55));		
		generalB.addActionListener(this);
		generalB.setActionCommand("general");
		generalP.add(generalB);
		menuPanel.add(generalP);		
				
		generalP = new JPanel();
		generalP.setBackground(new Color(255,255,255));
		proxyB = new JButton(proxyN);
		proxyB.setRolloverEnabled(true);		
		proxyB.setRolloverIcon(proxyS);	
		proxyB.setPressedIcon(proxyS);
		proxyB.setBorderPainted(false);				
		proxyB.setPreferredSize(new Dimension(87,53));
		proxyB.addActionListener(this);
		proxyB.setActionCommand("proxy");
		generalP.add(proxyB);
		menuPanel.add(generalP);
		
		generalP = new JPanel();
		generalP.setBackground(new Color(255,255,255));
		engineB = new JButton(engineN);
		engineB.setRolloverEnabled(true);		
		engineB.setRolloverIcon(engineS);	
		engineB.setPressedIcon(engineS);
		engineB.setBorderPainted(false);				
		engineB.setPreferredSize(new Dimension(90,55));
		engineB.addActionListener(this);
		engineB.setActionCommand("engine");
		generalP.add(engineB);
		menuPanel.add(generalP);
		
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.weighty = 1.0;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.fill = GridBagConstraints.VERTICAL;	
		panel.add(menuPanel,c);
		
		// Imposto il tipo di layout dei pannelli
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.weighty = 1.0;
		c.weightx = 1.0;
		c.fill = GridBagConstraints.BOTH;	
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		
		contentPanel.add(creaPannelloGeneral(),c);		
		c = new GridBagConstraints();
		c.gridx = 1;
		c.gridy = 0;
		c.weighty = 1.0;
		c.weightx = 1.0;
		c.fill = GridBagConstraints.BOTH;	
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		contentPanel.add(creaPannelloProxy(),c);
		
		c = new GridBagConstraints();
		c.gridx = 2;
		c.gridy = 0;
		c.weighty = 1.0;
		c.weightx = 1.0;
		c.fill = GridBagConstraints.BOTH;	
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		contentPanel.add(creaPannelloEngine(),c);
		
		// Visualizzo il pannello generale
		hideAllPanel();		
		switchToGeneralPanel();
		
		c = new GridBagConstraints();
		c.gridx = 1;
		c.gridy = 0;
		c.weighty = 1.0;
		c.weightx = 1.0;
		c.fill = GridBagConstraints.BOTH;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		panel.add(contentPanel,c);
		
	}
	
	/**
	 * Crea il pannello delle opzioni per il pattern matching
	 * @return
	 */
	private JPanel creaPannelloEngine() {
		EPEnginePanel tmp = new EPEnginePanel();	
		enginePanel = new JPanel();
		enginePanel.setBackground(new Color(255,255,255));
		enginePanel.add(tmp.getPanel());				
		return enginePanel;
	}
	
	/**
	 * Crea il pannello delle opzioni generali
	 * @return
	 */
	private JPanel creaPannelloGeneral() {
		GeneralPanel tmp = new GeneralPanel();		
		generalPanel = new JPanel();
		generalPanel.setBackground(new Color(255,255,255));
		generalPanel.add(tmp.getPanel());			
		return generalPanel;
	}
	
	/**
	 * Crea il pannello delle opzioni del proxy
	 * @return
	 */
	private JPanel creaPannelloProxy() {
		GridBagConstraints layout;
		proxyPanel = new JPanel();
		proxyPanel.setBackground(new Color(255,255,255));
		proxyError = new JLabel(" ");
		proxyError.setForeground(new Color(255,0,0));
		JPanel panel = new JPanel(new GridBagLayout());	
		panel.setBackground(new Color(255,255,255));
		panel.setPreferredSize(new Dimension(570,150));
		TitledBorder bordo =BorderFactory.createTitledBorder( BorderFactory.createLineBorder(new Color(223,217,233)),"General proxy options");			
				
		panel.setBorder(bordo);
		// Creo i componenti da inserire nel pannello principale
		box = new JCheckBox("Use proxy server");
		box.setBackground(new Color(255,255,255));
		box.setHorizontalAlignment(SwingConstants.CENTER);		
		box.addItemListener(this);
		JLabel serverLabel = new JLabel("Server ");		
		serverLabel.setPreferredSize(new Dimension(80,20));
		JLabel portLabel = new JLabel("Port   ");
		portLabel.setPreferredSize(new Dimension(80,20));
		JLabel timeoutLabel = new JLabel("Network Timeouts (only proxy server) [millisec] ");
		timeoutLabel.setPreferredSize(new Dimension(320,20));
		server = new JTextField("",20);		
		port = new JTextField("",7);
		proxyTimeout = new JTextField(String.valueOf(OptionControl.TIMEOUTPROXY),13);
		
		// Aggiungo i vari componenti
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;
		layout.gridwidth = 2;
		panel.add(box,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;
		panel.add(serverLabel,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 2;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;
		panel.add(server,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 3;		
		layout.anchor = GridBagConstraints.FIRST_LINE_START;
		panel.add(portLabel,layout);		
		
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 3;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;
		panel.add(port,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 4;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;
		panel.add(timeoutLabel,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 1;
		layout.gridy = 4;	
		layout.anchor = GridBagConstraints.FIRST_LINE_START;
		panel.add(proxyTimeout,layout);
		
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 5;	
		layout.gridwidth = 2;
		layout.anchor = GridBagConstraints.FIRST_LINE_START;
		panel.add(proxyError,layout);
							
		layout = new GridBagConstraints();
		layout.gridx = 0;
		layout.gridy = 0;	
		layout.weightx = 1.0;		
		layout.fill = GridBagConstraints.HORIZONTAL;
		JPanel mainPanel = new JPanel(new GridBagLayout()); 
		mainPanel.add(new JLabel(new ImageIcon("./img/proxyOptionsBar.gif")),layout);		
		
		layout.gridx = 0;
		layout.gridy = 1;	
		layout.weighty = 1.0;
		layout.weightx = 1.0;		
		layout.fill = GridBagConstraints.BOTH;		
		mainPanel.add(panel,layout);
		
		proxyPanel.add(mainPanel);		
		return proxyPanel;			
	}
	
	/**
	 * Permette di inserire i valori per impostare il proxy
	 *
	 */
	private void abilitaInputProxy() {
		port.setEditable(true);
		server.setEditable(true);
		proxyTimeout.setEditable(true);
	}
	
	/**
	 * Non permette di inserire i valori per impostare il proxy
	 *
	 */
	private void disabilitaInputProxy() {
		port.setEditable(false);
		server.setEditable(false);
		proxyTimeout.setEditable(false);
	}
	
	/**
	 * Ha il compito di reimpostare tutti i bottoni allo stato normal
	 *
	 */
	private void resetButton() {
		// Bottone delle general options
		generalB.setIcon(generalN);	
		generalB.setRolloverIcon(generalS);
		generalB.setPressedIcon(generalP);
		// Bottone delle opzioni del proxy
		proxyB.setIcon(proxyN);
		proxyB.setRolloverIcon(proxyS);
		proxyB.setPressedIcon(proxyP);
		// Bottone delle opzioni dell'engine
		engineB.setIcon(engineN);
		engineB.setRolloverIcon(engineS);
		engineB.setPressedIcon(engineP);
	}
	
	public void actionPerformed(ActionEvent e) {		
		if (e.getSource() instanceof JButton) {	
			hideAllPanel();
			if (e.getActionCommand() == "general") {
				// premuto il tasto General
				resetButton();
				switchToGeneralPanel();					
			}
			else if (e.getActionCommand() == "proxy") {
				// premuto il tasto Proxy Options
				resetButton();
				switchToProxyPanel();				
			}
			else if (e.getActionCommand() == "engine") {
				// premuto il tasto Proxy Options
				resetButton();
				switchToEnginePanel();				
			}				
		}		
	}
	
	public void itemStateChanged(ItemEvent e) {		
		switch(e.getStateChange()) {
		case(ItemEvent.SELECTED):
			// Utilizzo il proxy				
			String p = port.getText();
			String h = server.getText();
			String t = proxyTimeout.getText();
			String regex = "^\\d*?$"; // Indica che ho solo delle cifre			
			if (h != null && !h.equals("") && p != null && !p.equals("") && Pattern.matches(regex,p) && t != null && !t.equals("") && Pattern.matches(regex,t)) {	
				OptionControl.setProxyPort((int)Long.parseLong(p));
				OptionControl.setProxyTimeout((int)Long.parseLong(p));
				OptionControl.setProxyHost(h);
				if (OptionControl.portEvilProxy != OptionControl.getProxyPort()) {	// Controllo se è stata specificata la stessa porta			
					try { // Provo ad aprire il socket per vedere se è raggiungibile il server
						Socket cliente = new Socket(OptionControl.getProxyHost(),OptionControl.getProxyPort());
						cliente.setSoTimeout(OptionControl.getProxyTimeout());
						cliente.close();
						OptionControl.setProxy(true);
					}				
					catch (IOException ignored) {
						OptionControl.setProxy(false);
						if (BaseFrame.isInteractive()) {
							JOptionPane.showMessageDialog(null,"Unable to contact "+h+":"+p+" server.","Error",JOptionPane.ERROR_MESSAGE);
						}
					}		
				}
				else {
					proxyError.setText("Error: Proxy server port and EvilProxy port must be different");					
				}
			}
			else {
				OptionControl.setProxy(false);
				proxyError.setText("Error: One or more fields don't have a correct value");
			}
			if (OptionControl.isSetProxy()) {			
				firstTab.infoProxy.setText("[Proxy Enabled]");
			}
			break;
		case(ItemEvent.DESELECTED): {
			// Non utilizzo il proxy
			OptionControl.setProxy(false);	
			firstTab.infoProxy.setText("");			
			break;
		}
		}
		if (OptionControl.isSetProxy()) {
			box.setSelected(true);
			proxyError.setText(" ");
			disabilitaInputProxy();
		}
		else {
			box.setSelected(false);
			abilitaInputProxy();
		}
	}
	
	/**
	 * Rende invisibili tutti i pannelli tranne quello selezionato
	 *
	 */
	private void hideAllPanel() {		
		if (generalPanel.isVisible()) {			
			generalPanel.setVisible(false);				
		}
		if (proxyPanel.isVisible()) {			
			proxyPanel.setVisible(false);			
		}
		if (enginePanel.isVisible()) {			
			enginePanel.setVisible(false);			
		}		
	}
	
	/**
	 * Ha il compito di far visualizzare il pannello generale
	 * @return
	 */
	private void switchToGeneralPanel() {			
		generalPanel.setVisible(true); // Rendo il pannello visibile		
		// Imposto il bottone come attivato
		generalB.setRolloverIcon(null);
		generalB.setPressedIcon(null);
		generalB.setIcon(generalA);
		
	}
	
	/**
	 * Ha il compito di far visualizzare il pannello di engine
	 *
	 */
	private void switchToEnginePanel() {
		enginePanel.setVisible(true); // Rendo il pannello visibile		
		// Imposto il bottone come attivato
		engineB.setRolloverIcon(null);
		engineB.setPressedIcon(null);
		engineB.setIcon(engineA);
		
		
		
	}
	
	/**
	 * Ha il compito di far visuenginePanelalizzare il pannello delle opzioni del proxy
	 *
	 */
	private void switchToProxyPanel() {
		proxyPanel.setVisible(true); // Rendo il pannello visibile
		// Imposto il bottone come attivato
		proxyB.setRolloverIcon(null);
		proxyB.setPressedIcon(null);
		proxyB.setIcon(proxyA);		
	}
	
	public JPanel getTab() {
		return panel;
	}
}
