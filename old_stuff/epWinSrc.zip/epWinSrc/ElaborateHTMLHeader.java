import java.util.regex.Pattern;
import java.io.*;
import java.util.regex.Matcher;
import java.util.ArrayList;
import java.net.Socket;

/**
 * Gli viene passato nel costruttore l'header HTML oppure l'intera richiesta e ritorna tutte le informazioni del caso
 * @author s4tan
 *
 */
public class ElaborateHTMLHeader {
	private String header = "";
	private String data = "";
	private String firstLine = "";

	ElaborateHTMLHeader(String h) {
		int endHeader;		
		if (h == null) {
			return;
		}
		endHeader = h.indexOf("\r\n\r\n"); // Indica la fine dell'header HTML
		if (endHeader == -1) {
			// Non è presente il carattere \r\n\r\n
			endHeader = h.length();
		}
		header = h.substring(0,endHeader); // Ottengo l'header, senza il\r\n\r\n finale	
		if (h.length() >= endHeader+4) {
			data = h.substring(endHeader+4,h.length());
		}
		
		// Ottengo la prima riga dell'header
		int endFirstLine = header.indexOf("\r\n");
		if (endFirstLine < 0) { // l'header è formato da una sola riga
			firstLine = new String(header);
		}
		else {
			firstLine = header.substring(0,endFirstLine);
		}
		
	}
	
	
	/**
	 * Ritorna un array list con elencati tutti i parametri dell'url nella forma "nome=valore"
	 * @return
	 */
	public ArrayList getURLParameters(ArrayList<String> pos) {
		ArrayList<String> pars = null;
		String regex = " .*?(\\?|#)(.*?) ";
		Matcher mt;
		Pattern pt;
		
		pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		mt = pt.matcher(firstLine);
		int lung = 0;
		String prs;
		if (mt.find()) {
			lung = mt.start(2);
			pars = new ArrayList<String>();
			prs = mt.group(2);
			prs = prs.trim()+"&";
			regex = "(.*?)&";
			pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
			mt = pt.matcher(prs);
			int a,b;
			while(mt.find()) {
				a = mt.start(1)+lung;
				b = mt.end(1)+lung;
				pars.add(mt.group(1));				
				pos.add(a+","+b);				
			}
		}		
		return pars;
	}
	
	/**
	 * Ritorna un array list con elencati tutti i cookie presenti, nella forma "nome=valore"
	 * @return
	 */
	public ArrayList getCookies(ArrayList<String> pos) {
		String regex = "Cookie:(.*)$";
		Matcher mt;
		Pattern pt;
		pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE);
		mt = pt.matcher(header);
		String cookie = null;
		if (mt.find()) {
			cookie = mt.group(1);
			cookie = cookie.trim();	
		}
		if (cookie != null && !cookie.equals("")) {
			ArrayList<String> pars = new ArrayList<String>();
			if (!cookie.endsWith(";"))
				cookie = cookie + ";";
			int lung = mt.start(1);
			regex = "(.*?);";
			pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
			mt = pt.matcher(cookie);
			int a,b;
			while(mt.find()) {
				a = mt.start(1)+lung;
				b = mt.end(1)+lung;
				pars.add(mt.group(1));		
				pos.add(a+","+b);
			}	
			return pars;
		}
		return null;
	}
	
	/**
	 * Ritorna un array list con elencati tutti i parametri del body presenti, nella forma "nome=valore"
	 * @return
	 */
	public ArrayList getBodyParameters(ArrayList<String> pos) {		
		if (this.getData() != null && !this.getData().equals("")) {
			ArrayList<String> pars = new ArrayList<String>();
			Matcher mt;
			Pattern pt;
			String prs = this.getData();			
			prs = prs.trim()+"&";			
			String regex = "(.*?)&";
			
			pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
			mt = pt.matcher(prs);
			int a,b;
			int lung = header.length()+4;
			while(mt.find()) {
				a = mt.start(1)+lung;
				b = mt.end(1)+lung;
				pos.add(a+","+b);		
				pars.add(mt.group(1));
			}
			return pars;
		}		
		return null;
	}
	
	/**
	 * Ritorna il valore del campo preso in input, altrimenti null
	 * @param f
	 * @return
	 */
	public String getField(String f) {
		if(f == null || f.equals("") || header == null || header.equals("")) {
		 return null;
	    }
		String value = null; 
		String regex = f+"(.*)";
		Matcher mt;
		Pattern pt;
		pt = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		mt = pt.matcher(header);
		if (mt.find()) {
			value = mt.group(1);
			value = value.trim();
		}		
		return value;
	}
	
	/**
	 * Ritorna l'encoding del body
	 * @return
	 */
	public String encoding() {
		int typeI = header.toLowerCase().indexOf("content-encoding:");
		if (typeI < 0) {
			return "";
		}
		String type;
		int end = header.indexOf("\r\n",typeI);
		if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
			end = header.length();
		}
				
		type = header.substring(typeI+17,end);
		type = type.trim();		
		return type;
	}

	
	
	/**
	 * Ritorno il valore del campo Host
	 * @return
	 */
	public String getHostFromClientRequest() {
		int start = 0;		
		start = header.toLowerCase().indexOf("host:");
		if (start == -1) {
			// Non è presente l'host
			return null;
		}
		int end = header.toLowerCase().indexOf("\r\n",start);
		if (end < 0) {
			end = header.length();
		}
		if (start+6 <= end) {
			String H = header.substring(start+6,end);
			H = H.trim();
			return H;
		}
		return "";
	}	 
	
	/**
	 * Funzione che ritorna l'eventuale porta impostata nell'url
	 * @return
	 */
	public int getPortFromUrlField() {		
		int endCar =  firstLine.indexOf("//");
		String firstLine = new String(this.firstLine);
		if (endCar > 0) { // elimino il protocollo
			firstLine = this.firstLine.substring(endCar+2,this.firstLine.length());
		}		
		int startPt = firstLine.indexOf(":"); // Controllo se è impostata anche la porta
		if (startPt > -1) {
			String host = "";
			String pt = null;
			String regex = "^\\d*?$"; // Indica che ho solo delle cifre
			// è stata specificata anche la porta
			// Elimino gli eventuali parametri
			endCar = firstLine.indexOf("?");					
			if (endCar == -1) {
				endCar = firstLine.indexOf("#");
			}
			if (endCar == -1) {
				endCar = firstLine.length();
			}
			host = firstLine.substring(0,endCar); // Ho eliminato gli eventuali parametri
			
			endCar = host.indexOf("/",startPt);					
			if (endCar == -1) { // Non è stato specificato nessun nome di file, solo l'host
				endCar = host.length();
			}			
			if (startPt+1 < endCar) {
				pt = host.substring(startPt+1,endCar);				
			}
			if (pt != null && Pattern.matches(regex,pt)) { // Ricavo la porta						
				return (int)Long.parseLong(pt);						
			}
		}				
		return -1; // Porta non settata
		
	}
	
	/**
	 * 
	 * @return Ritorna l'url della richiesta fatta dal client
	 */
	public String getUrlFromClientRequest() {		
		int urlI = firstLine.indexOf(" ");
		String url = "";		
		if (urlI > -1) {
			int end = 0;
			if (urlI+1 <= firstLine.length()) {
				end = firstLine.indexOf(" ",urlI+1);
			}
			if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
				end = firstLine.indexOf("\r\n",urlI);
			}	
			if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
				end = firstLine.length();
			}		
			if (end >= urlI+1) {
				url = firstLine.substring(urlI+1,end);
				url = url.trim();
			}
			else {
				url = "";
			}
		}		
		return url;
	}
	
	/**
	 * 
	 * @return Ritorna il metodo utilizzato dal client per ottenere la pagina
	 */
	public String getMethod() {
		int end = firstLine.indexOf(" ");
		if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
			end = firstLine.indexOf("\r\n");
		}	
		if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
			end = firstLine.length();
		}			
		return firstLine.substring(0,end);
		
	}
	
	/**
	 * 
	 * @return Ritorna i dati presenti nella richiesta
	 */
	public String getData() {
		return data;
	}
	

	/**
	 * 
	 * @return Ritorna lo status della risposta ricevuta
	 */
	public String getStatusFromServerResponse() {					
		int statusI = firstLine.indexOf(" ");
		String status;
		if (statusI < 0) {
			return "Unknown";
		}
		int end = 0;
		if (statusI+1 < firstLine.length()) {
			end = firstLine.indexOf(" ",statusI+1);
		}
		
		if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
			end = firstLine.indexOf("\r\n",statusI);
		}	
		if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
			end = firstLine.length();
		}		
		if (statusI > -1) {
			status = firstLine.substring(statusI+1,end);
			status = status.trim();
		}
		else {
			status = "Unknown";
		}
		return status;
	}
	
	/**
	 * 
	 * @return Ritorna la lunghezza della risposta del server in formato numerico
	 */
	public int getIntLengthFromServerResponse() {
		String regex = "^\\d*?$"; // Indica che ho solo delle cifre
		String len = this.getLengthFromServerResponse();		
		if (len != null && !len.equals("") && Pattern.matches(regex,len)) {					
			return (int)Long.parseLong(len);	
		}		
		return -1;		
	}
	
	/**
	 * 
	 * @return Ritorna la lunghezza della risposta del server
	 */
	public String getLengthFromServerResponse() {
		int lengthI = header.toLowerCase().indexOf("content-length:");
		if (lengthI < 0) {			
			return "";
		}
		String length;
		int end = header.indexOf("\r\n",lengthI);
		if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
			end = header.length();
		}
				
		length = header.substring(lengthI+16,end);
		length = length.trim();	
		return length;
	}
	
	/**
	 * 
	 * @return Ritorna il tipo di richiesta della risposta del server
	 */
	public String getTypeFromServerResponse() {
		int typeI = header.toLowerCase().indexOf("content-type:");
		if (typeI < 0) {
			return "";
		}
		String type;
		int end = header.indexOf(";",typeI);
		if (end == -1) {
			end = header.indexOf("\r\n",typeI);
		}
		if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
			end = header.length();
		}
				
		type = header.substring(typeI+14,end);
		type = type.trim();		
		return type;
	}
	
	/**
	 * Aggiorna il campo Content-Length, il base alla reale lunghezza dei dati.
	 * @return Ritorna l'intera richiesta: header+data
	 */
	public String getUpdateHeaderLength() {
		int realLength = data.length();
		
		int lenI = header.toLowerCase().indexOf("content-length:");
		if (lenI < 0) { // Il campo non è presente
			return header+"\r\n\r\n"+data;
		}
		int end = header.indexOf("\r\n",lenI);
		if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
			end = header.length();
		}
				
		header = header.substring(0,lenI+16)+realLength+header.substring(end,header.length());		
		return header+"\r\n\r\n"+data;
	}
	
	/**
	 * 
	 * @return Ritorna i cookie trovati nella richiesta
	 */
	public String getCookieFromServerResponse() {			
		String cookie = "";
		int cookieI = 0;
		int startCookie = 0;
		int end;
		// Controllo se ci sono cookie settati
		while((cookieI = header.toLowerCase().indexOf("cookie:",startCookie)) > -1) {
			// Ho dei cookie settai
			end = header.indexOf("\r\n",cookieI);
			if (end == -1) { // Caso eccezionale, non dovrebbe mai accadere
				end = header.length();
			}
			cookie = cookie+" "+header.substring(cookieI+7,end);
			cookie = cookie.trim();					
			startCookie = cookieI+7;
		}
		return cookie;
	}
	
	/** 
	 * @return Ritorna il tipo di file che è stato richiesto nell'header. Funzione utilizzata per le richieste dal browser
	 */	
	public String getTypeFileFromClientRequest() {
		if (getMethod().toLowerCase().equals("connect")) {
			// Trattasi di connessione SSL
			return "Unknown";
		}
		// Imposto il tipo di file richiesto
		int typeI = firstLine.indexOf(" ");
		int endCar = firstLine.indexOf(" ",typeI+1);
		if (endCar == -1) { // Caso particolare non dovrebbe mai verificarsi
			endCar = firstLine.indexOf("\r",typeI+1);
		}
		if (endCar == -1) { // Caso particolare non dovrebbe mai verificarsi
			endCar = firstLine.length();
		}
		String type = firstLine.substring(typeI+1,endCar); // Ho ottenuto l'host		
		// Elimino gli eventuali parametri preceduti dai caratteri ? o #
		endCar = type.indexOf("?");					
		if (endCar == -1) {
			endCar = type.indexOf("#");
		}
		if (endCar == -1) {
			endCar = type.length();
		}
		type = type.substring(0,endCar); // Ho eliminato gli eventuali parametri					
		// Controllo se è presente il protocollo
		endCar = type.indexOf("//");
		if (endCar > -1) { // Elimino il protocollo
			type = type.substring(endCar+2,type.length());
		}					
		endCar = type.lastIndexOf("/");					
		if (endCar >= -1) {
			typeI = type.indexOf(".",endCar);
			if (typeI > -1) {
				type = type.substring(typeI+1,type.length());
				type = type.trim();
			}
			else { // Non ho un'estensione, impossibile determinare il tipo
				type = "Unknown";
			}
		}
		else { // L'host non finisce con /, impossibile determinare il tipo
			type = "Unknown";						
		}
		return type;
	}	
}
