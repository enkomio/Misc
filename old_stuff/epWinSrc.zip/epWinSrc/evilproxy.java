
public class evilproxy{
	
	public static void main(String[] args) {		
		ep evilProxy = new ep(args);
		evilProxy.startEvilProxy();
		
	}

}
