import java.net.Socket;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.regex.Pattern;

/**
 * @author s4tan, s4tan@ictsc.it
 *
 */

public class Connection extends Thread{
	private Socket client;
	private BufferedReader reader;
	private BufferedWriter writer;
	
	// La porta è l'host vengono impostate quando si legge la richiesta da parte del browser
	private String host = ""; // contiene l'indirizzo del server a cui è diretta la richiesta
	private int port = 80; // contiene la porta del server a cui ci si deve connettere per inoltrare la richiesta del browser
	
	private int carLetti = 0; // numeri di caratteri letti dalla funzione leggiRiga()
	// Messaggio di errore in caso di richiesta non valida
	private final String ERRORMESSAGE = "<h1>Invalid request</h1><h3>Powered by <i>evilproxy</i></h3>";
		
	/**
	 * Ottiene il socket come parametro, e istanzia un nuovo BufferedReader per poter leggere le info
	 * @param client
	 */
	Connection(Socket client) {
		super();
		this.client = client;		
	}
	
	public String getHost() {
		return host;
	}
	
	public int getPort() {
		return port;
	}
		
	/**
	 * Identica alla funzione readLine, soltanto che ritorna la riga soltanto quando incontra i caratteri \r\n dal BufferedReader reader
	 * @return
	 */
	private String leggiRiga() {
		return leggiRiga(reader);
	}
	
	/**
	 * Identica alla funzione readLine, soltanto che ritorna la riga soltanto quando incontra i caratteri \r\n dal BufferedReader 
	 * specificato come parametro
	 * @return
	 */
	private String leggiRiga(BufferedReader reader) {
		boolean finito = false;
		char car;
		int ch = 0;
		int contatore = 0;
		String riga = "";
		while (!finito) {
			try {
				ch = reader.read();				
			}
			catch (IOException ignored) {ignored.printStackTrace();}
			car = (char)ch;
			riga = riga+car;
			switch (ch) {
			case 13:
				if (contatore == 0) { // Ho incontrato \r
					contatore++;
				}				
				else {
					contatore = 0;
				}
				break;
			case 10:
				if (contatore == 1) { // Ho incontrato \r\n
					contatore++;
				}				
				else {
					contatore = 0;
				}
				break;
			default:
				contatore = 0;
			}	
			if (contatore == 2) { // Ho incontrato \r\n
				finito = true;
			}	
		}
		carLetti = riga.length();
		return riga;
	}	
	
	/**
	 * Ritorna il numero di caratteri letti dell'ultima invocazione della funzione leggiRiga (con o senza parametro).
	 * Il numero di caratteri comprende anche i caratteri speciali \r e \n. Quindi per una riga vuota (solo caratteri \r\n) ritorna 2.
	 * @return
	 */
	private int numCarLetti() {
		return carLetti;
	}
	
	/**
	 * Legge la richiesta del browser. Non si aspetta nessun dato (dunque legge soltanto l'header).
	 * Termina di leggere appena incontra la sequenza di caratteri \r\n\r\n
	 * @return
	 */
	private String leggiRequest() {	
		String line = leggiRiga();
		String header = "";		
		String value = null; // Contiene il valore della lunghezza dei dati
		String regex = "^\\d*?$"; // Indica che ho solo delle cifre		
		while(numCarLetti() > 2) {			
			// Ho dei dati dell'header	
			if (line.toLowerCase().startsWith("content-length")) { // Ricavo il Content-length
				// Ho dei dati oltre all'header
				int start = line.indexOf(":");	
				if (start+1 < line.length()) {
					value = line.substring(start+1,line.length());
					value = value.trim();
				}
			}			
			else if (line.toLowerCase().startsWith("host")) { // Ricavo l'host			
				int start = line.indexOf(":");
				if (start+1 < line.length()) {
					host = line.substring(start+1,line.length());
					host = host.trim();
				}					
				// Controllo se è impostata la porta nel campo host
				int startP = host.indexOf(":");				
				if (startP >=0 && startP+1 < host.length()) {// è stata impostata la porta
					String stringPort = host.substring(startP+1,host.length());
					if (stringPort != null && !stringPort.equals("") && Pattern.matches(regex,stringPort)) {
						host = host.substring(0,startP); // Ricalcolo l'host
						port = (int)Long.parseLong(stringPort);
					}					
				}				
			}
			header = header+line;
			line = leggiRiga();
		}
		header = header+line; // Aggiungo gli ultimi caratteri letti (\r\n)
		// Controllo se nella richiesta ho dei dati da leggere, se si leggo in base alla lunghezza impostata		
		long number = 0;		
		if (value != null && Pattern.matches(regex,value)) {
			long lungCorrente = 0;
			number = Long.parseLong(value);
			int ch = 0;
			char car;
			while (lungCorrente < number) {				
				try {
					ch = reader.read();
				}
				catch (IOException ignored) {}
				car = (char)ch;				
				lungCorrente++;
				header = header+car;				
			}
			
		}		
		return header;
	}	
	
	/**
	 * Ha il compito di gestire l'intera connessione. 
	 * I passi principali (in termini di messaggi inviati) sono
	 * 	1. browser -> proxy
	 * 	2. elaborazione richiesta
	 * 	3. proxy -> server			| GESTITA ESTERNAMENTE
	 * 	4. server -> proxy			| GESTITA ESTERNAMENTE
	 * 	5. elaborazione risposta	| GESTITA ESTERNAMENTE
	 * 	6. proxy -> browser			| GESTITA TRAMITE LA CHIAMATA A forwardResponse(String response)
	 */
	public void run() {
		String firstline = null;		
		try {			
			reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
			writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(),"ISO-8859-1"));	
			firstline = reader.readLine();
		}	
		catch(IOException ignored) {ignored.printStackTrace();}
		
		String header = "";
		header = firstline+"\r\n";
		
		boolean isSSL = false;
		if (firstline.toLowerCase().startsWith("connect")) { // Controllo se è una connessione SSL			
			isSSL = true;
		}
			
		int startUrl = header.indexOf(" ");
		int endUrl = header.indexOf(" ",startUrl+1);
		String url = "";
		String metodo = "";
			
		if (startUrl+1 < endUrl) {
			url = header.substring(startUrl+1,endUrl);
		}		
			
		if (startUrl > 0) {
			metodo = header.substring(0,startUrl);
		}
			
		// Ottengo l'header della richiesta da parte del browser (passo 1)
		header = header+leggiRequest();		
		
		// Controllo se nell'url è definita la porta. Se si prendo questa come buona rispetto a quella definita nell'host (se definita)
		ElaborateHTMLHeader fl = new ElaborateHTMLHeader(url);
		if (fl.getPortFromUrlField() > 0) { // Ho impostato la porta nell'url
			port = fl.getPortFromUrlField();			
		}		
		
		// Controllo se mi è arrivata una richiesta valida			
		if (getHost().equals(client.getLocalAddress().getHostAddress()) && getPort() == client.getLocalPort()) {
			try {
				writer.write(ERRORMESSAGE);
				writer.flush();
				
				reader.close();	
				writer.close();
				client.close();
			}
			catch (IOException ignored) {ignored.printStackTrace();}
			return;
		}
			
		// Aggiungo l'header alla lista delle richieste da elaborare affinchè venga modificato (passo 2)
		infoRichiesta info = new infoRichiesta(header,getHost(),getPort(),client.getInetAddress().getHostName(),client.getPort(),this,url,metodo,isSSL);
		synchronized(SchedulerRequest.requests) { // Notifico l'aggiunta di una richiesta in coda
			SchedulerRequest.addRequest(info);
			SchedulerRequest.requests.notify();
		}
	}	
	
	/**
	 * Inoltre al browser le risposte opportunamente modificate del server
	 *
	 */
	public void forwardResponse(String response) {		
		try {			
			writer.write(response);			
			writer.flush();
			
		
			// Ho inoltrato le richieste, posso chiudere le connessioni
			reader.close();	
			writer.close();
			client.close();	
		}
		catch (IOException ignored) {}
	}
	
	/**
	 * Abortisce la connessione
	 *
	 */
	public void dropConnection() {
		try {			
			reader.close();	
			writer.close();
			client.close();	
		}
		catch (IOException ignored) {ignored.printStackTrace();}
	}


} // End Classe
