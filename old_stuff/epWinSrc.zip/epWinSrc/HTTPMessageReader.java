/**
 * Classe utilizzata per la lettura di un messaggio HTTP
 */

import java.io.*;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

public class HTTPMessageReader extends BufferedInputStream {

	private int	BUFFER_SIZE = 20480;
	private final String CRLF = "\r\n";
	private final String CRLF2 = CRLF + CRLF;
	private final String LF = "\n";
	private final String LF2 = LF + LF;
	public final String CONTENT_LENGTH 	= "Content-length";
	
	private int contentLength = -1;		
	private byte[] mBuffer = new byte[BUFFER_SIZE];
	private boolean isChuncked = false;
	private int lenChunckedString = 0;
	
	private String headerLetto;
	
	HTTPMessageReader(Socket socket, int len) throws IOException {
		super(socket.getInputStream());
		BUFFER_SIZE = len;		
	}
	
	HTTPMessageReader(Socket socket) throws IOException {
		super(socket.getInputStream());
	}
	
	public InputStream getInputStream() {
		return super.in;
	}
	
		
	public synchronized HttpBody readZippedBody() {
		HttpBody tmp = readBody(false);
		try {
			String str = tmp.toString();	
			int size = str.length();
			int start1 = headerLetto.toLowerCase().indexOf("content-encoding:");			
			int start2 = headerLetto.toLowerCase().indexOf("transfer-encoding:");
			int start3 = headerLetto.toLowerCase().indexOf("content-length:");		
						
			GZIPInputStream zipin = new GZIPInputStream(new StringInputStream(str));
			
			String tmp1 = "";
		    int len;		   
		    byte[] buffer = new byte[20000];
		    String foo;
		    while ((len = zipin.read(buffer)) > -1) {
		    	foo = new String(buffer, 0, len);
		    	tmp1 = tmp1+foo;
		    }		
		    
		    // Creo il nuovo header
		    String newHeader = new String(headerLetto);
		    if (start1 >= 0) {
		    	// Ho il content-encoding, lo elimino
		    	newHeader = newHeader.replaceAll("Content-Encoding:.*(\r|\n)(\r|\n)","");
		    }
		    if (start2 >= 0) {
		    	// Ho il transfer-encoding, lo elimino
		    	newHeader = newHeader.replaceAll("Transfer-Encoding:.*(\r|\n)(\r|\n)","");		    	
		    }
		    if (start3 >= 0) {
		    	// Ho il content-length, lo aggiorno
		    	newHeader = newHeader.replaceAll("Content-Length:.*(\r|\n)(\r|\n)","Content-Length: "+tmp1.length()+"\r\n");		    	
		    }
		    else {
		    	// Non ho il content-length, lo inserisco alla fine dell'header
		    	newHeader = newHeader.replaceAll("\r\n\r\n","\r\nContent-Length: "+tmp1.length()+"\r\n\r\n");
		    }
		    newHeader = newHeader+tmp1;			    
		    return new HttpBody(newHeader);
		}
		catch (IOException e) {e.printStackTrace();}
		
		return tmp;
	}
		
	
	/**
	 * Read Http body from input stream as a string basing on the content length on the method.
	 * @param method
	 * @return Http body
	 */
	public synchronized HttpBody readBody() {
		return this.readBody(true);
	}
	
	
	/**
	 * Read Http body from input stream as a string basing on the content length on the method.
	 * Se gli viene passato true, legge tutto, altrimenti non ritorna la lunghezza dei pezzi chuncked
	 * @param method
	 * @return Http body
	 */
	public synchronized HttpBody readBody(boolean y) {
		
		int readBodyLength = 0;
		int len = 0;				
		HttpBody body = (contentLength > 0) ? new HttpBody(contentLength) : new HttpBody();
		
		try {
			if (isChuncked) {
				while(isChuncked) {
					// Leggo tutti i vari pezzi
					contentLength = readChunckedLength(mBuffer);					
					if (y) {
						body.append(mBuffer,lenStringChunckedLength());
					}											
					if (contentLength == 0) { // Finito di leggere
						isChuncked = false;
						continue;
					}										
					while (contentLength == -1 || readBodyLength < contentLength) {						
						len = readBody(contentLength, readBodyLength, mBuffer);						
						if (len > 0) {
							readBodyLength += len;
							body.append(mBuffer, len);					
						}	
						else {
							break;
						}								
					}
					readBodyLength = 0;
				}
				
			}
			else { // Leggo il content-length specificato
				while (contentLength == -1 || readBodyLength < contentLength) {				
					len = readBody(contentLength, readBodyLength, mBuffer);				
					if (len > 0) {
						readBodyLength += len;
						body.append(mBuffer, len);					
					}	
					else {
						break;
					}								
				}
			}
		} catch (IOException e) {}		
		return body;
	}	
	
	/**
	 * Ritorna la lunghezza della stringa identificante la lunghezza del pezzo di pagina dell'ultima lettura
	 * @return
	 */
	private int lenStringChunckedLength() {
		return lenChunckedString;
	}
	
	/**
	 * Legge la lunghezza del pezzo e la restituisce. Inoltre aggiunge la stringa al buffer passato
	 * @return
	 */
	private int readChunckedLength(byte[] buffer) throws IOException {
		int len = 0;
		int ob = -1;		
		char[] tmp = new char[BUFFER_SIZE];
		StringBuffer sb = new StringBuffer(200);
		int i = 0;
		do {
			ob = super.read(); // Leggo un byte		
			sb.append((char)ob);						
			buffer[i++] = (byte)ob;				
		} while(!isLineEnd(sb));
		
		String line = sb.toString();		
		lenChunckedString = i;
		line = line.trim();
		try {				
			len = Long.decode("0X"+line).intValue();			
		}
		catch (NumberFormatException ignored) {}	
		return len;
	}
	
	
	private int readBody(int contentLengthP, int readBodyLength, byte[] buffer) throws IOException {

		int len = 0;
		int remainingLen = 0;

		if (contentLengthP == -1) {			
			len = super.read(buffer);
		} else {			
			remainingLen = contentLengthP - readBodyLength;
			if (remainingLen < buffer.length && remainingLen > 0) {
				len = super.read(buffer,0,remainingLen);

			} else if (remainingLen > buffer.length) {
				len = super.read(buffer);

			}
		}
		return len;
	}
	
	public String readHeader() throws IOException {
		String msg = "";
        int		oneByte = -1;
        boolean eoh = false;
        boolean neverReadOnce = true;
        StringBuffer sb = new StringBuffer(200);
        Pattern myPattern = null;
		Matcher myMatcher;		
        
        do {
            oneByte = super.read();
        	
        	if (oneByte == -1) {
        		eoh = true;
        		if (neverReadOnce) {
        			try {
        				Thread.sleep(20);
        			}
        			catch(InterruptedException ignored) {}
        			continue;
        		}
				break;
        	} else {
        		neverReadOnce = false;
        	}
            sb.append((char) oneByte);

            if (((char) oneByte) == '\n' && isHeaderEnd(sb)) {
                eoh = true;
                msg = sb.toString();
            }
		} while (!eoh || neverReadOnce); 
        // Calcolo il Content-Length
        ElaborateHTMLHeader h = new ElaborateHTMLHeader(msg);	
        contentLength = h.getIntLengthFromServerResponse();   
        String foo = h.getField("Transfer-Encoding:");
        if (contentLength < 0 && foo != null && foo.toLowerCase().equals("chunked")) {
        	isChuncked = true;        	
        }        
        headerLetto = msg;
        return msg;

	}

	/**
	 * Check if the current StringBuffer trailing characters is an HTTP header end (empty CRLF).
	 * @param sb
	 * @return true - if end of HTTP header.
	 */
	private boolean isHeaderEnd(StringBuffer sb) {
		int len = sb.length();
		if (len > 2) {
			if (LF2.equals(sb.substring(len-2))) {
				return true;
			}
		}
	
		if (len > 4) {
			if (CRLF2.equals(sb.substring(len-4))) {
				return true;
			}
		}
	
		return false;
	}
	
	private boolean isLineEnd(StringBuffer sb) {
		int len = sb.length();
		if (len > 2) {
			if (CRLF.equals(sb.substring(len-2))) {				
				return true;
			}
		}		
		return false;		
	}
	
	public int read() throws IOException {
		return super.read();

	}
	public int read(byte[] b) throws IOException {
		return super.read(b);

	}
	
	public int read(byte[] b, int off, int len) throws IOException {
		return super.read(b, off, len);

	}

	public void close() {
		try {
		    super.close();
		} catch (Exception e) {
			
		}
	}

}

class StringInputStream extends InputStream {
	private StringReader str;
	
	StringInputStream(String s) {
		str = new StringReader(s);
	}
	
	public int read() throws IOException {
		return str.read();
	}
	
}
