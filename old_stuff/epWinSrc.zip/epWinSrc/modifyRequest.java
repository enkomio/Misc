import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import javax.swing.JOptionPane;

/**
 * Questa classe ha il compito di modificare le richieste che gli arrivano, di inoltrarle verso
 * la GUI, attendere che quest'ultima gli dia l'OK (generato da parte dell'utente) e reinviarle alla Connection
 * @author s4tan
 *
 */

public class modifyRequest {
	private String request = "";
	private String infoRequest;
	private boolean ssl = false; // Mi dice se la sessione corrente è di tipo SSL
	public static boolean showRequest = true;
	public static boolean showResponse = true;
	
	private boolean responseDropped = false;
	private boolean requestsDropped = false;
	private int lastMatchedFieldInRequests = 0;
	private int lastMatchedFieldInResponses = 0;
	
	BaseFrame gui;	
	
	modifyRequest(String req, String info) {
		if (req != null) {
			request = req;
		}
		gui = new BaseFrame();		
		infoRequest = info;
	}
	
	public void setSSL(boolean s) {
		ssl = s;
	}
	
	/**
	 * Controlla che la richiesta non sia nella lista dei files da non visualizzare
	 * @return
	 */
	private boolean mustShowClientRequest() {
		if (!OptionControl.ignoreClientFiletypes) {			
			return true;
		}
		ElaborateHTMLHeader h = new ElaborateHTMLHeader(request); 
		String type = h.getTypeFileFromClientRequest();		
		if (OptionControl.ignoredClientFiletypes.toLowerCase().indexOf(type.toLowerCase())>=0) {			
			return false;
		}
		else {			
			return true;
		}		
	}
	
	/**
	 * Controlla che la risposta sia o meno da visualizzare
	 * @return
	 */
	private boolean mustShowServerResponse() {
		if (OptionControl.ignoreServerNonTextResponse) {			
			ElaborateHTMLHeader h = new ElaborateHTMLHeader(request); 
			String type = h.getTypeFromServerResponse();		
			if (type.toLowerCase().indexOf("text")>=0) {			
				return true;
			}
			else {			
				return false;
			}
		}
		return true;
				
	}
	
	/**
	 * Ritorna la richiesta ricevuta dal client modificata
	 * @return
	 */
	public String getModifiedRequest() {
		requestsDropped = false; // Lo setto preventivamente
		if (OptionControl.modifyClientRequests) { // Devo modificarla
			request = modificaRichiesta(request);
		}
		if (BaseFrame.isInteractive() && OptionControl.interceptClientRequest && mustShowClientRequest()) { // Devo attendere la risposta dall'utente			
			gui.setInfoRequest(infoRequest,ssl);			
			showRequest = true;
			gui.setRequest(request); // Faccio visualizzare la richiesta nella gui
			firstTab.abilitaModificaParametri(true); // Attivo la modifica parametri
			int decision = gui.getUserDecision(); 	// Ottenfo la decisione dell'utente
			firstTab.abilitaModificaParametri(false); // Disattivo la modifica parametri
			if (decision == 1) {
				// Decisione di forward
				request = gui.getTesto(); // Ottengo il testo della textarea
				return request;
			}
			else {
				// Decisione di drop
				requestsDropped = true;
				return "";
			}			
		}
		else { // Non è settato il modo interattivo, modifico la richiesta e la invio subito alla Connection
			if (mustShowClientRequest()) {
				showRequest = true;
			}
			else {
				showRequest = false;
			}		
			return request;
				
		}		
	}
	
	/**
	 * Ritorna la risposta ricevuta dal server modificata
	 * @return
	 */
	public String getModifiedResponse() {
		responseDropped = false; // Lo imposto preventivamente
		if (OptionControl.modifyServerResponses) { // Devo modificarla
			request = modificaRisposta(request);
		}		
		if (BaseFrame.isInteractive() && OptionControl.interceptServerResponse && mustShowServerResponse()) { // Devo attendere la risposta dell'utente			
			gui.setInfoRequest(infoRequest,ssl);
			showResponse = true;
			gui.setRequest(request); // Faccio visualizzare la richiesta nella gui			
			if (gui.getUserDecision() == 1) {
				// Decisione di forward
				request = gui.getTesto(); // Ottengo il testo della textarea
				return request;
			}
			else {
				// Decisione di drop
				responseDropped = true;
				return "";
			}
		}
		else { // Non è settato il modo interattivo, invio subito alla Connection
			if (mustShowServerResponse()) {
				showResponse = true;
			}
			else {
				showResponse = false;
			}	
			return request;
		}		
	}
	
	
	/**
	 * modifica effettivamente la richiesta
	 * @param req
	 * @return
	 */
	public String modificaRichiesta(String R) {		
		Boolean tmp;
		ArrayList foo;
		Pattern myPattern = null;
		Matcher myMatcher;		
		
		String req = new String(R);
		// Compilo il flag del pattern
		int F = Pattern.CANON_EQ; // Valore di default
		if (OptionControl.matchingRequestsMultiline) {
			F = F | Pattern.DOTALL;
		}
		if (!OptionControl.matchingRequestsSensitive) {
			F = F | Pattern.CASE_INSENSITIVE;
		}	
		if (OptionControl.matchingRequestsAnchor) {			
			F = F | Pattern.MULTILINE;
		}
		
		for(int i=0;i<OptionControl.listaRequests.size();i++) {
			foo = (ArrayList)OptionControl.listaRequests.get(i);
			tmp = (Boolean)(foo.get(0));
			if (tmp.booleanValue() ) {	
				myPattern = Pattern.compile((String)foo.get(1),F);				
				myMatcher = myPattern.matcher(req);
				lastMatchedFieldInRequests = myMatcher.groupCount();
				try {					
					req = myMatcher.replaceAll((String)foo.get(2));	
				}
				catch (IndexOutOfBoundsException ignored) {
					if (BaseFrame.isInteractive()) {						
						JOptionPane.showMessageDialog(null,"Error in Requests regular expression syntax: Match=\""+(String)foo.get(1)+"\" Replace=\""+(String)foo.get(2)+"\".\nMaybe there are some variables that are not setted.\nPlease control your regular expression.","Error",JOptionPane.ERROR_MESSAGE);
					}
					break;
				}							
			}
		}		
		return req;
	}	
	
	/**
	 * Ritorna quante volte è stata matchata la richiesta
	 * @return
	 */
	public int getNumLastMatchedFieldInRequests() {
		return lastMatchedFieldInRequests;
	}
	
	/**
	 * modifica effettivamente la richiesta
	 * @param req
	 * @return
	 */
	public String modificaRisposta(String R) {
		Boolean tmp;
		ArrayList foo;
		Pattern myPattern = null;
		Matcher myMatcher;		
		
		String req = new String(R);
		// Compilo il flag del pattern
		int F = Pattern.CANON_EQ; // Valore di default
		if (OptionControl.matchingResponsesMultiline) {
			F = F | Pattern.DOTALL;
		}
		if (!OptionControl.matchingResponsesSensitive) {
			F = F | Pattern.CASE_INSENSITIVE;
		}
		if (OptionControl.matchingResponsesAnchor) {			
			F = F | Pattern.MULTILINE;
		}
		
		for(int i=0;i<OptionControl.listaResponses.size();i++) {
			foo = (ArrayList)OptionControl.listaResponses.get(i);
			tmp = (Boolean)(foo.get(0));
			if (tmp.booleanValue() ) {				
				myPattern = Pattern.compile((String)foo.get(1),F);
				myMatcher = myPattern.matcher(req);
				lastMatchedFieldInResponses = myMatcher.groupCount(); 
				try {					
					req = myMatcher.replaceAll((String)foo.get(2));	
				}
				catch (IndexOutOfBoundsException ignored) {
					if (BaseFrame.isInteractive()) {						
						JOptionPane.showMessageDialog(null,"Error in Responses regular expression syntax: Match=\""+(String)foo.get(1)+"\" Replace=\""+(String)foo.get(2)+"\".\nMaybe there are some variables that are not setted.\nPlease control your regular expression.","Error",JOptionPane.ERROR_MESSAGE);
					}
					break;
				}							
			}
		}		
		return req;
	}	
	
	/**
	 * Mi dice se la risposta è stata droppata
	 * @return
	 */
	public boolean isResponsesDropped() {
		return responseDropped;
	}
	
	/**
	 * Ritorna quante volte è stata matchata la risposta
	 * @return
	 */
	public int getNumLastMatchedFieldInResponses () {
		return lastMatchedFieldInResponses;	
	}
	
	/**
	 * Mi dice se la richiesta è stata droppata
	 * @return
	 */
	public boolean isRequestDropped() {
		return requestsDropped;
	}
	
}
