/**
 * Contiene le informazioni scambiate tra le Connection e lo Scheduler
 * @author s4tan
 *
 */
public class infoRichiesta {
	private String header = null;
	private String hostServer = null;
	private String hostHost = null;
	private String url = null;
	private String method = null;
	private int portServer = 0;
	private int portHost = 0;
	private Connection conn = null;
	private boolean ssl = false;
	
	infoRichiesta() {}
	/**
	 * Contiene le informazioni relative alle richieste ricevute
	 * @param h		Richiesta ricevuta
	 * @param hs	Host a cui inviare la richiesta
	 * @param p		Porta dell' host a cui inviare la richiesta
	 * @param hh	Host che ha inviato la richiesta
	 * @param ph	Porta dell' host a cha ha fatto la richiesta
	 * @param c		Riferimento alla connessione che ha riempito i dati
	 * @param u		Identifica l'url di destinazione
	 * @param m		Identifica il metodo usato
	 * @param ssl	Mi dice se la connessione è di tipo SSL
	 */
	infoRichiesta(String h, String hs, int p, String hh, int ph, Connection c, String u, String m, boolean ssl) {
		setHeader(h);
		setHostServer(hs);
		setPortServer(p);
		setHostHost(hh);
		setPortHost(ph);
		setConnection(c);
		setUrl(u);
		setMethod(m);
		setSSL(ssl);
	}
	
	public void setSSL(boolean d) {
		ssl = d;
	}
	
	public boolean isSSL() {
		return ssl;
	}
	
	public String getHeader() {
		return header;
	}
	
	public String getUrl() {
		return url;
	}
	
	public void setUrl(String u) {
		url = u;
	}
	
	public String getMethod() {
		return method;
	}
	
	public void setMethod(String v) {
		method = v;
	}
	
	public String getHostServer() {
		return hostServer;
	}
	
	public int getPortServer() {
		return  portServer;
	}
	
	public int getPortHost() {
		return  portHost;
	}
	
	public void setPortHost(int p) {
		portHost = p;
	}
	
	public String getHostHost() {
		return  hostHost;
	}
	
	public void setHostHost(String hh) {
		hostHost = hh;
	}
	
	
	public Connection getConnection() {
		return conn;
	}
	
	public void setHeader(String h) {
		header = h;
	}
	
	public void setHostServer(String h) {
		hostServer = h;		
	}
	
	public void setPortServer(int p) {
		portServer = p;
	}
	
	public void setConnection(Connection c) {
		conn = c;
	}
	
}
