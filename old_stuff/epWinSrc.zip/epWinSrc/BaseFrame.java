import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;

import net.infonode.tabbedpanel.*;
import net.infonode.tabbedpanel.theme.*;
import net.infonode.tabbedpanel.titledtab.TitledTab;
import net.infonode.tabbedpanel.titledtab.TitledTabProperties;



/**
 * Implementa la GUI di evilproxy
 * 
 * @author s4tan
 * 
 */
public class BaseFrame extends WindowAdapter {

	private JPanel panel; // Pannello principale

	private GridBagConstraints c;

	private static boolean interactive = OptionControl.isInteractive;

	private static TabbedPanel tab;
	private TitledTabProperties titledTabProperties = new TitledTabProperties();
	
	private static firstTab tab0;
	private static secondTab tab1;
	private static thirdTab tab2;
	
	private TabbedPanelTitledTabTheme theme = new ShapedGradientTheme();
	//private static TitledTab primoTab;

	private String tmpText; // Variabile temporanea che contiene il testo della
	
	public static Integer userDecision = new Integer(-1); // Stato di attesa
	public static Integer semVisualizza = new Integer(-1);

	private static JFrame frame;

	/**
	 * Visualizza una finestra con il messaggio passato come parametro
	 * @param s Identifica il testo da visualizzare
	 * @param t Identifica il titolo da visualizzare
	 * @param d Identifica il tipo di icona davisualizzare, è una costante di JOptionPane
	 */
	public static void message(String s, String t, int d) {
		if (BaseFrame.isInteractive()) {
			JOptionPane.showMessageDialog(null,s,t,d);
		}
		
	}
	
	// Funzioni per la creazione dei vari pannelli
	private TitledTab createFirstTab() {
		TitledTab tab = new TitledTab("Intercept", new ImageIcon("./img/interception.gif"), tab0.getTab(), null);		    
		tab.getProperties().addSuperObject(titledTabProperties);
		//primoTab = tab;
		return tab;
	}
	 
	private TitledTab createSecondTab() {
	    TitledTab tab = new TitledTab("Options", new ImageIcon("./img/option.gif"), tab1.getTab(), null);		    
	    tab.getProperties().addSuperObject(titledTabProperties);
	    return tab;
	}
	 
	private TitledTab createThirdTab() {
	    TitledTab tab = new TitledTab("Request queque", new ImageIcon("./img/queque.gif"), tab2.getTab(), null);		    
	    tab.getProperties().addSuperObject(titledTabProperties);
	    return tab;
	}
	
	/**
	 * Metodi per la gestione della GUI. L'interfaccia grafica si avvia soltanto
	 * se è la variabile interactive è impostata a true (valore di default)
	 * 
	 * @param choice
	 */
	public void setInteractive(boolean choice) {
		interactive = choice;
	}

	/**
	 * Imposta la label che ha il compito di visualizzare le info riguardanti la
	 * richiesta. ssl mi dice se è una connessione di tipo ssl.
	 * 
	 * @param req
	 * @param ssl
	 */
	public void setInfoRequest(String req, boolean ssl) {
		tab0.setInfoRequest(req, ssl);
	}

	public static boolean isInteractive() {
		return interactive;
	}

	BaseFrame() {
		super();		
		frame = new JFrame();		
	}

	/**
	 * Inserisce nella text area del tab0 la richiesta (una stringa) che gli
	 * viene passata come parametro
	 * 
	 * @param req
	 */
	public void setRequest(String req) {
		tab0.setRequest(req);
	}

	/**
	 * Ritorna la scelta (ovvero se droppare oppure forwardare il messaggio)
	 * effettuata dall'utente
	 * 
	 * @return
	 */
	public int getUserDecision() {		
		synchronized(userDecision) {			
			try {				
				firstTab.enableForward(true);
				firstTab.enableDrop(true);
				userDecision.wait(); // Attendo il segnale da parte dell'utente
			}
			catch(InterruptedException ignored) {}						
		}	
						
		int tmp = firstTab.decision;
		firstTab.decision = -1; // Reimposto la decisione a: nessuna decisione		
		tmpText = firstTab.getTesto(); // lo salvo in una mia variabile
		firstTab.deleteText();
		return tmp;
	}

	/**
	 * Ritorna il testo della textarea
	 * 
	 * @return
	 */
	public String getTesto() {
		return tmpText;
	}

	public static void setChoiceInHystoryQueque(int choice, int row, int col) {
		if (!isInteractive()) {
			return;
		}
		tab2.setChoice(choice, row, col);
	}

	public static void setChoiceInHystoryQueque(Object choice, int row, int col) {
		if (!isInteractive()) {
			return;
		}
		tab2.setChoice(choice, row, col);
	}

	public static void addVoiceRequest(infoRichiesta v) {
		if (!isInteractive()) {
			return;
		}
		tab2.addVoice(v);
	}

	public static void evidenziaTab() {
		if (!isInteractive()) {
			return;
		}
		// Non posso evidenziare, spesso crasha il pannello
		/*
		if (!primoTab.isSelected()) {			
			primoTab.setSelected(true);	
		}	
		*/	
	}

	public static void nonEvidenziaTab() {
		if (!isInteractive()) {
			return;
		}		
	}

	public void showGUI() {
		this.showGUI(0);
	}
	
	/**
	 * Visualizza la gui, il parametro passato identifica il look&Feel che dovrà essere usato
	 * @param v
	 */
	public void showGUI(int v) {
		UIManager.LookAndFeelInfo looks[];
		looks = UIManager.getInstalledLookAndFeels();
		if (!isInteractive()) {
			return;
		}
		frame.setTitle(OptionControl.NAME+" v" + OptionControl.VERSION);
		frame.addWindowListener(this);		
		ImageIcon logo = new ImageIcon("./img/logo.gif");
		frame.setIconImage(logo.getImage()); 
		try {
			UIManager.setLookAndFeel(looks[v].getClassName());
		}
		catch(Exception e) {}
		
		// Creo il pannello principale e lo aggiungo al JFrame
		panel = new JPanel(new GridBagLayout());
		panel.setBackground(new Color(255, 255, 255));
		frame.getContentPane().add(panel);

		// Creo la barra decorativa
		JPanel decoratorPanel = new JPanel(new GridBagLayout());
		decoratorPanel.setBackground(new Color(56, 58, 59));
		decoratorPanel.setPreferredSize(new Dimension(10, 10));
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1.0;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(decoratorPanel, c);

		// Creo la barra del logo in un nuovo pannello
		JPanel bannerPanel = new JPanel(new GridBagLayout());
		JLabel banner = new JLabel(new ImageIcon("./img/banner.gif"), 0);
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1.0;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		bannerPanel.setBackground(new Color(115, 111, 109));
		bannerPanel.add(banner, c);
		// Aggiungo il nuovo pannello al pannello principale
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1.0;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add(bannerPanel, c);

		// Creo la JTabbedPane
		Insets oldInsets = UIManager.getInsets("TabbedPane.contentBorderInsets");
		UIManager.put("TabbedPane.contentBorderInsets", new Insets(5, 1, 1, 1));		
		
		tab = new TabbedPanel();
		tab.getProperties().addSuperObject(theme.getTabbedPanelProperties());
		titledTabProperties.addSuperObject(theme.getTitledTabProperties());		
		UIManager.put("TabbedPane.contentBorderInsets", oldInsets);
		tab.setPreferredSize(new Dimension(OptionControl.X, OptionControl.Y));
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.insets = new Insets(5,0,0,0);
		c.fill = GridBagConstraints.BOTH;
		panel.add(tab, c);
		
		
		// Creo e aggiungo i vari tab
		tab0 = new firstTab();
		tab.addTab(createFirstTab());
		tab1 = new secondTab();
		tab.addTab(createSecondTab());
		tab2 = new thirdTab();
		tab.addTab(createThirdTab());

		frame.pack();
		frame.setVisible(true);
	}

	/**
	 * Gestisce le operazioni da effettuare alla chiusura dell'applicazione
	 */
	public void windowClosing(WindowEvent e) {
		SchedulerRequest.closeLog(); // Chiudo il file di log
		frame.setVisible(false);
		System.exit(0);
	}

}
